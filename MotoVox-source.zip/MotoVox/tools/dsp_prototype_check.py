#!/usr/bin/env python3
"""Python re-implementation of MotoVox's PitchShifter / Limiter / Biquad high-pass / WAV header layout.
Purpose: sanity-check the ALGORITHMS and pick unit-test tolerances. This does NOT test the Kotlin code."""
import math, struct
try:
    import numpy as np
except ImportError:
    np = None

SR = 48000

def pitch_shift(x, ratio, window_ms=45.0):
    win = max(64, int(SR * window_ms / 1000)); size = win * 2 + 4
    buf = [0.0] * size; w = 0; phase = 0.0; out = []
    def read(d):
        pos = w - d
        while pos < 0: pos += size
        i0 = int(math.floor(pos)) % size; fr = pos - math.floor(pos)
        return buf[i0] * (1 - fr) + buf[(i0 + 1) % size] * fr
    for s in x:
        buf[w] = s
        pB = (phase + 0.5) % 1.0
        sa = math.sin(math.pi * phase); sb = math.sin(math.pi * pB)
        out.append(read(phase * win) * sa * sa + read(pB * win) * sb * sb)
        phase += (1.0 - ratio) / win; phase -= math.floor(phase)
        w = (w + 1) % size
    return out

def zero_cross_freq(y, start, n):
    seg = y[start:start + n]; c = 0
    for a, b in zip(seg, seg[1:]):
        if a <= 0 < b: c += 1
    return c * SR / n

def limiter(x, ceiling_db=-0.5, release_ms=120.0):
    ceil = 10 ** (ceiling_db / 20); rel = 1 - math.exp(-1.0 / (SR * release_ms / 1000)); g = 1.0; out = []
    for s in x:
        a = abs(s); t = ceil / a if a * g > ceil else 1.0
        g = t if t < g else g + (t - g) * rel
        out.append(max(-ceil, min(ceil, s * g)))
    return out

def highpass(x, f, q=0.7071):
    w0 = 2 * math.pi * f / SR; c = math.cos(w0); al = math.sin(w0) / (2 * q)
    b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al
    b0, b1, b2, a1, a2 = b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0
    z1 = z2 = 0.0; out = []
    for s in x:
        y = b0 * s + z1; z1 = b1 * s - a1 * y + z2; z2 = b2 * s - a2 * y; out.append(y)
    return out

def rms(v): return math.sqrt(sum(a * a for a in v) / len(v))

sine = lambda f, n, a=0.5: [a * math.sin(2 * math.pi * f * i / SR) for i in range(n)]

print("== pitch shifter (input 440 Hz sine, measured via zero crossings after 0.3 s warm-up) ==")
for st in (-6, -3, 3, 7, 12):
    ratio = 2 ** (st / 12); y = pitch_shift(sine(440, SR), ratio)
    f = zero_cross_freq(y, 15000, 24000); exp = 440 * ratio
    print(f"  {st:+3d} st  expected {exp:7.1f} Hz  measured {f:7.1f} Hz  err {abs(f-exp)/exp*100:4.1f}%")
y = pitch_shift(sine(440, SR), 1.0); print(f"  ratio 1.0 gain: in rms {rms(sine(440,SR)):.3f} out rms {rms(y[15000:]):.3f}")

print("== limiter ==")
loud = [min(3.0, max(-3.0, 3.0 * s)) for s in sine(220, SR, 1.0)]
lo = limiter(loud); print(f"  input peak {max(map(abs,loud)):.2f} -> output peak {max(map(abs,lo)):.4f} (ceiling {10**(-0.5/20):.4f})")

print("== high-pass 90 Hz ==")
for f in (30, 60, 90, 180, 1000):
    y = highpass(sine(f, SR), 90); print(f"  {f:5d} Hz  gain {rms(y[24000:])/rms(sine(f,SR)[24000:]):.3f}")

print("== WAV header layout ==")
n = 1000; hdr = struct.pack('<4sI4s4sIHHIIHH4sI', b'RIFF', 36 + n * 2, b'WAVE', b'fmt ', 16, 1, 1, 48000, 96000, 2, 16, b'data', n * 2)
print(f"  header bytes = {len(hdr)} (expected 44)")
