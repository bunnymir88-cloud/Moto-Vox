#!/usr/bin/env python3
"""Rasterizes the MotoVox logo (same path data as gen_logo.py) to PNGs with PIL, for previews / store listings."""
import math, os, re, sys
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = open(os.path.join(ROOT, "tools/gen_logo.py")).read()
def const(n): return re.search(n + r' = "([^"]+)"', src).group(1)
HELMET, VISOR, GREEN, RED, RING = [const(n) for n in ("HELMET", "VISOR", "BARS_GREEN", "BAR_RED", "RING")]

def flatten(d, steps=24):
    toks = re.findall(r'[A-Za-z]|-?\d*\.?\d+', d); i = 0; cmd = None; polys = []; cur = []; x = y = 0.0
    def num():
        nonlocal i; v = float(toks[i]); i += 1; return v
    while i < len(toks):
        if re.match(r'[A-Za-z]', toks[i]): cmd = toks[i]; i += 1
        if cmd == 'M': x, y = num(), num(); cur = [(x, y)]; cmd = 'L'
        elif cmd == 'L': x, y = num(), num(); cur.append((x, y))
        elif cmd == 'h': x += num(); cur.append((x, y))
        elif cmd == 'v': y += num(); cur.append((x, y))
        elif cmd == 'C':
            x1, y1, x2, y2, x3, y3 = [num() for _ in range(6)]
            for k in range(1, steps + 1):
                t = k / steps; u = 1 - t
                cur.append((u**3*x + 3*u*u*t*x1 + 3*u*t*t*x2 + t**3*x3, u**3*y + 3*u*u*t*y1 + 3*u*t*t*y2 + t**3*y3))
            x, y = x3, y3
        elif cmd == 'A':
            rx, ry, rot, large, sweep, ex, ey = [num() for _ in range(7)]
            # circle arc through endpoints (rx == ry), centre computed like SVG spec
            dx, dy = (x - ex) / 2, (y - ey) / 2; d2 = dx*dx + dy*dy; r = rx
            co = math.sqrt(max(0, (r*r - d2) / d2)) * (-1 if large == sweep else 1)
            cx = (x + ex) / 2 + co * dy; cy = (y + ey) / 2 - co * dx
            a0 = math.atan2(y - cy, x - cx); a1 = math.atan2(ey - cy, ex - cx)
            if sweep and a1 < a0: a1 += 2 * math.pi
            if not sweep and a1 > a0: a1 -= 2 * math.pi
            for k in range(1, steps * 2 + 1):
                a = a0 + (a1 - a0) * k / (steps * 2); cur.append((cx + r*math.cos(a), cy + r*math.sin(a)))
            x, y = ex, ey
        elif cmd in 'zZ':
            if cur: polys.append(cur); cur = []
            continue
    if cur: polys.append(cur)
    return polys

def render(size, bg=True, ss=4):
    S = size * ss; k = S / 108.0
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
    if bg:
        dr.rectangle((0, 0, S, S), fill=(8, 11, 16, 255))
        dr.ellipse((14*k, 14*k, 94*k, 94*k), fill=(17, 24, 32, 255))
    fill = lambda path, col: [dr.polygon([(px*k, py*k) for px, py in p], fill=col) for p in flatten(path)]
    fill(HELMET, (245, 247, 250, 255)); fill(VISOR, (8, 11, 16, 255))
    fill(GREEN, (57, 229, 140, 255)); fill(RED, (255, 48, 72, 255))
    pts = [(px*k, py*k) for px, py in flatten(RING)[0]]
    dr.line(pts, fill=(255, 48, 72, 255), width=int(3.2*k), joint="curve")
    for p in (pts[0], pts[-1]): r = 1.6*k; dr.ellipse((p[0]-r, p[1]-r, p[0]+r, p[1]+r), fill=(255, 48, 72, 255))
    return im.resize((size, size), Image.LANCZOS)

if __name__ == "__main__":
    out = os.path.join(ROOT, "branding"); os.makedirs(out, exist_ok=True)
    render(1024).save(f"{out}/motovox_logo_1024.png"); render(512).save(f"{out}/motovox_logo_512.png")
    # preview sheet: sizes + circle mask + rounded-square mask on light and dark backgrounds
    sheet = Image.new('RGB', (760, 330), (28, 28, 32)); sheet.paste(render(256), (10, 10))
    x = 290
    for s in (96, 64, 48, 36):
        t = render(s); sheet.paste(t, (x, 20), t); x += s + 14
    for bgc, ox in (((245, 247, 250), 290), ((18, 18, 22), 530)):
        sheet.paste(Image.new('RGB', (230, 170), bgc), (ox, 150))
        base = render(144)
        m = Image.new('L', (144, 144), 0); ImageDraw.Draw(m).ellipse((0, 0, 143, 143), fill=255)
        sheet.paste(base.convert('RGB'), (ox + 10, 160), m)
        m2 = Image.new('L', (144, 144), 0); ImageDraw.Draw(m2).rounded_rectangle((0, 0, 143, 143), 36, fill=255)
        sm = base.resize((64, 64), Image.LANCZOS); m2s = m2.resize((64, 64), Image.LANCZOS)
        sheet.paste(sm.convert('RGB'), (ox + 160, 160), m2s)
    sheet.save(f"{out}/preview_sheet.png"); print("wrote PNGs + preview_sheet.png")
