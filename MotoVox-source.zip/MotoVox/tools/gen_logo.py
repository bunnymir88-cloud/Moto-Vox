#!/usr/bin/env python3
"""Generates MotoVox logo assets (Android vector XML + editable SVG) from one set of paths."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "app/src/main/res/drawable")
HELMET = "M30,66 C28,44 40,30 56,30 C72,30 82,40 82,54 L82,66 C82,69 80,71 77,71 L36,71 C32,71 30,69 30,66 Z"
VISOR = "M49,43 L76,43 C78,43 79,44.5 79,46 L79,57 C79,58.5 78,60 76,60 L52,60 C50,60 48.5,58.5 48.5,56.5 Z"
BARS_GREEN = "M55,48.5h2.4v6h-2.4z M59.5,46.5h2.4v10h-2.4z M68.5,47h2.4v9h-2.4z M73,49h2.4v5h-2.4z"
BAR_RED = "M64,45.5h2.4v12h-2.4z"
RING = "M28,69 A30,30 0 0 0 80,69"
NS = 'xmlns:android="http://schemas.android.com/apk/res/android"'

def vec(w, vw, body, extra=""):
    return f'<?xml version="1.0" encoding="utf-8"?>\n<vector {NS}\n    android:width="{w}dp" android:height="{w}dp"\n    android:viewportWidth="{vw}" android:viewportHeight="{vw}">\n{extra}{body}</vector>\n'

fg = (f'    <path android:fillColor="#F5F7FA" android:pathData="{HELMET}" />\n'
      f'    <path android:fillColor="#080B10" android:pathData="{VISOR}" />\n'
      f'    <path android:fillColor="#39E58C" android:pathData="{BARS_GREEN}" />\n'
      f'    <path android:fillColor="#FF3048" android:pathData="{BAR_RED}" />\n'
      f'    <path android:strokeColor="#FF3048" android:strokeWidth="3.2" android:strokeLineCap="round" android:pathData="{RING}" />\n')
open(f"{RES}/ic_launcher_foreground.xml", "w").write(vec(108, 108, fg))

bg = ('    <path android:fillColor="#080B10" android:pathData="M0,0h108v108h-108z" />\n'
      '    <path android:fillColor="#111820" android:pathData="M54,54m-40,0a40,40 0 1,1 80,0a40,40 0 1,1 -80,0" />\n')
open(f"{RES}/ic_launcher_background.xml", "w").write(vec(108, 108, bg))

mono = (f'    <path android:fillColor="#000000" android:fillType="evenOdd" android:pathData="{HELMET} {VISOR}" />\n'
        f'    <path android:fillColor="#000000" android:pathData="{BARS_GREEN} {BAR_RED}" />\n'
        f'    <path android:strokeColor="#000000" android:strokeWidth="3.2" android:strokeLineCap="round" android:pathData="{RING}" />\n')
open(f"{RES}/ic_launcher_monochrome.xml", "w").write(vec(108, 108, mono))

notif = (f'    <group android:translateX="-24" android:translateY="-24">\n'
         f'    <path android:fillColor="#FFFFFF" android:fillType="evenOdd" android:pathData="{HELMET} {VISOR}" />\n'
         f'    <path android:fillColor="#FFFFFF" android:pathData="{BARS_GREEN} {BAR_RED}" />\n'
         f'    <path android:strokeColor="#FFFFFF" android:strokeWidth="3.2" android:strokeLineCap="round" android:pathData="{RING}" />\n'
         f'    </group>\n')
open(f"{RES}/ic_notif.xml", "w").write(vec(24, 60, notif))

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" width="1024" height="1024">
  <rect width="108" height="108" fill="#080B10"/>
  <circle cx="54" cy="54" r="40" fill="#111820"/>
  <path d="{HELMET}" fill="#F5F7FA"/>
  <path d="{VISOR}" fill="#080B10"/>
  <path d="{BARS_GREEN}" fill="#39E58C"/>
  <path d="{BAR_RED}" fill="#FF3048"/>
  <path d="{RING}" fill="none" stroke="#FF3048" stroke-width="3.2" stroke-linecap="round"/>
</svg>
'''
open(os.path.join(ROOT, "branding/motovox_logo.svg"), "w").write(svg)
print("logo assets written")
