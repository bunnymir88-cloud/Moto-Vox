package com.motovox.app

import android.Manifest
import android.media.AudioRecord
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rules.GrantPermissionRule
import com.motovox.app.audio.AudioCapture
import com.motovox.app.audio.AudioDevices
import com.motovox.app.data.RecStatus
import com.motovox.app.recording.RecConfig
import com.motovox.app.recording.RecState
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented tests. They need a device/emulator with a microphone. They do NOT prove wired/USB/Bluetooth behavior:
 * those routes need a physical phone with the actual accessory (see HARDWARE_TEST_PLAN.md).
 */
@RunWith(AndroidJUnit4::class)
class DeviceHardwareTests {
    @get:Rule val perm: GrantPermissionRule = GrantPermissionRule.grant(Manifest.permission.RECORD_AUDIO)
    private val app get() = InstrumentationRegistry.getInstrumentation().targetContext.applicationContext as MotoVoxApp

    @Test fun enumeratesAtLeastOneInput() = assertTrue(AudioDevices.list(app).isNotEmpty())

    @Test fun builtInMicOpensAndDeliversSamples() {
        val o = AudioCapture.open(app, 48000, 1, null)
        assertNotNull(o.error, o.record)
        val ar = o.record!!
        try { ar.startRecording(); val b = ShortArray(4800); assertTrue(ar.read(b, 0, b.size) > 0) }
        finally { ar.stop(); ar.release() }
    }

    @Test fun recorderProducesFinalizedWavAndSupportsPause() {
        val rec = app.recorder
        rec.start(RecConfig("InstrumentedTest", 48000, 1))
        waitFor { rec.ui.value.state == RecState.RECORDING }
        Thread.sleep(1500); rec.pause(); assertEquals(RecState.PAUSED, rec.ui.value.state)
        val atPause = rec.ui.value.elapsedMs; Thread.sleep(700); assertEquals(atPause, rec.ui.value.elapsedMs)
        rec.resume(); Thread.sleep(800); rec.addMarker("test"); rec.stop()
        waitFor { rec.ui.value.state == RecState.IDLE }
        val m = app.repo.items.value.first { it.name == "InstrumentedTest" }
        assertEquals(RecStatus.COMPLETE, m.status); assertTrue(m.durationMs > 1500); assertEquals(1, m.markers.size)
        assertNull(com.motovox.app.audio.WavIO.validate(app.repo.fileOf(m)))
        app.repo.delete(m.id)
    }

    private fun waitFor(timeoutMs: Long = 5000, c: () -> Boolean) {
        val end = System.currentTimeMillis() + timeoutMs
        while (!c()) { if (System.currentTimeMillis() > end) fail("timeout"); Thread.sleep(50) }
    }
}
