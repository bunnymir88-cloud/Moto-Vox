package com.motovox.app.recording

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioRecord
import android.media.AudioRouting
import android.os.Handler
import android.os.Looper
import android.os.Process
import com.motovox.app.audio.AudioCapture
import com.motovox.app.audio.AudioDevices
import com.motovox.app.audio.BluetoothRoute
import com.motovox.app.audio.Levels
import com.motovox.app.audio.SyncTone
import com.motovox.app.audio.WavIO
import com.motovox.app.data.Marker
import com.motovox.app.data.Naming
import com.motovox.app.data.RecStatus
import com.motovox.app.data.RecordingKind
import com.motovox.app.data.RecordingMeta
import com.motovox.app.data.RecordingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.IOException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.max

private class Seg(val meta: RecordingMeta, val writer: WavIO.Writer, val startFrame: Long)

/**
 * Capture thread (high priority, only reads the mic + meters + enqueues) -> unbounded queue -> writer thread (disk I/O).
 * The WAV header is refreshed every ~5 s so a killed process loses at most a few seconds; startup recovery repairs the rest.
 */
class RecorderEngine(private val ctx: Context, private val repo: RecordingRepository) {
    private val _ui = MutableStateFlow(RecUiState())
    val ui: StateFlow<RecUiState> = _ui.asStateFlow()

    @Volatile private var paused = false
    @Volatile private var stopRequested = false
    @Volatile private var capturedFrames = 0L
    @Volatile private var sampleRate = 48000
    private val markers = CopyOnWriteArrayList<Marker>()

    fun isActive() = _ui.value.state.let { it != RecState.IDLE && it != RecState.ERROR }

    private fun transition(ev: RecEvent): Boolean {
        var ok = false
        _ui.update { cur ->
            val n = RecStateMachine.next(cur.state, ev)
            ok = n != null
            if (n != null) cur.copy(state = n) else cur
        }
        return ok
    }

    fun start(cfg: RecConfig) {
        if (!transition(RecEvent.START)) return
        paused = false; stopRequested = false; capturedFrames = 0; markers.clear()
        _ui.update { RecUiState(state = it.state, projectName = cfg.projectName) }
        Thread({ runSession(cfg) }, "MotoVox-capture").start()
    }

    fun pause() { if (transition(RecEvent.PAUSE)) paused = true }
    fun resume() { if (transition(RecEvent.RESUME)) paused = false }
    fun stop() { if (transition(RecEvent.STOP)) { stopRequested = true; paused = false } }
    fun dismissError() { transition(RecEvent.RESET); _ui.update { if (it.state == RecState.IDLE) it.copy(message = null) else it } }
    fun reportError(msg: String) { _ui.update { it.copy(message = msg) }; transition(RecEvent.FAIL) }

    fun addMarker(label: String = ""): Boolean {
        val st = _ui.value.state
        if (st != RecState.RECORDING && st != RecState.PAUSED) return false
        val t = capturedFrames * 1000L / sampleRate
        markers.add(Marker(t, label.ifBlank { "Marker ${markers.size + 1}" }))
        _ui.update { it.copy(markers = markers.toList()) }
        return true
    }

    private fun fail(msg: String) { _ui.update { it.copy(message = msg) }; stopRequested = true; transition(RecEvent.FAIL) }

    private fun updateRoute(ar: AudioRecord, requested: AudioDeviceInfo?) {
        val d = ar.routedDevice ?: return
        val kind = AudioDevices.classify(d.type)
        val label = AudioDevices.label(kind, d.type)
        val name = d.productName?.toString()?.takeIf { it.isNotBlank() } ?: label
        val note = if (requested != null && d.id != requested.id && d.type != requested.type)
            "The selected input isn't in use. Android is recording from: $name ($label)." else null
        _ui.update { it.copy(routeName = "$name — $label", routeNote = note) }
    }

    private fun readError(code: Int) = when (code) {
        AudioRecord.ERROR_DEAD_OBJECT -> "The audio input was disconnected or taken over by the system."
        AudioRecord.ERROR_INVALID_OPERATION -> "Android reported the audio input is no longer valid."
        else -> "Audio capture failed (code $code)."
    }

    private fun runSession(cfg: RecConfig) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = cfg.sampleRate; val ch = cfg.channels
        sampleRate = sr
        if (repo.dir.usableSpace < 50L * 1024 * 1024) { fail("Not enough free storage to start recording (need at least 50 MB)."); return }

        val device = AudioDevices.find(ctx, cfg.deviceId)
        if (cfg.deviceId >= 0 && device == null)
            _ui.update { it.copy(routeNote = "The selected input isn't connected. Using Android's default input.") }
        var btActive = false
        if (device != null && AudioDevices.isBluetooth(device)) {
            btActive = BluetoothRoute.activate(ctx, device)
            if (!btActive) _ui.update { it.copy(routeNote = "Couldn't route to the Bluetooth microphone (permission or profile unavailable).") }
            else try { Thread.sleep(800) } catch (e: InterruptedException) { Thread.currentThread().interrupt() }
        }
        val opened = AudioCapture.open(ctx, sr, ch, device)
        val ar = opened.record
        if (ar == null) { fail(opened.error ?: "Couldn't start recording."); if (btActive) BluetoothRoute.release(ctx); return }

        val startedAt = System.currentTimeMillis()
        val queue = LinkedBlockingQueue<ShortArray>()
        val poison = ShortArray(0)
        val segs = ArrayList<Seg>()
        val writeError = AtomicReference<String?>(null)
        val segLimit = if (cfg.splitMinutes > 0) cfg.splitMinutes * 60L * sr else Long.MAX_VALUE

        fun openSeg(startFrame: Long): Seg {
            val part = segs.size + 1
            val base = Naming.fileName(cfg.projectName, startedAt, if (cfg.splitMinutes > 0) "part$part" else "voice")
            var f = File(repo.dir, base); var n = 2
            while (f.exists()) { f = File(repo.dir, base.removeSuffix(".wav") + "_$n.wav"); n++ }
            val meta = RecordingMeta(
                id = repo.newId(),
                name = if (cfg.splitMinutes > 0) "${cfg.projectName} (part $part)" else cfg.projectName,
                fileName = f.name, kind = RecordingKind.VOICE, createdAt = startedAt + startFrame * 1000L / sr,
                durationMs = 0, sampleRate = sr, channels = ch, sizeBytes = 0, status = RecStatus.RECORDING,
                inputDevice = _ui.value.routeName
            )
            repo.upsert(meta)
            return Seg(meta, WavIO.Writer(f, sr, ch), startFrame).also { segs.add(it) }
        }

        val writer = Thread({
            var seg: Seg? = null; var total = 0L; var sinceHeader = 0L
            try {
                while (true) {
                    val chunk = queue.take()
                    if (chunk === poison) break
                    if (seg == null || seg.writer.frames >= segLimit) { seg?.writer?.close(); seg = openSeg(total) }
                    seg.writer.write(chunk, chunk.size)
                    val frames = chunk.size / ch
                    total += frames; sinceHeader += frames
                    if (sinceHeader >= sr * 5L) {
                        seg.writer.flushHeader(); sinceHeader = 0
                        if (repo.dir.usableSpace < 20L * 1024 * 1024) {
                            writeError.set("Storage is almost full. Recording was stopped and everything so far was saved.")
                            stopRequested = true
                        }
                    }
                }
            } catch (e: IOException) {
                writeError.set("Couldn't write audio (${e.message}). Storage may be full. Everything recorded so far was kept.")
                stopRequested = true
            } finally { segs.lastOrNull()?.let { s -> runCatching { s.writer.close() } } }
        }, "MotoVox-writer")
        writer.start()

        val gain = Levels.dbToLinear(cfg.gainDb)
        val buf = ShortArray(sr / 20 * ch)
        val listener = AudioRouting.OnRoutingChangedListener { updateRoute(ar, device) }
        ar.addOnRoutingChangedListener(listener, Handler(Looper.getMainLooper()))
        var clipCount = 0; var silent = 0L; var hold = 0f

        try {
            ar.startRecording()
            if (ar.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                fail("Android refused to start the microphone. Another app or a phone call may be using it.")
            } else {
                transition(RecEvent.STARTED)
                updateRoute(ar, device)
                if (cfg.syncTone) { markers.add(Marker(0, "Sync tone")); _ui.update { it.copy(markers = markers.toList()) }; SyncTone.play() }
                var stoppedForPause = false
                while (!stopRequested) {
                    if (paused) {
                        if (!stoppedForPause) { ar.stop(); stoppedForPause = true; _ui.update { it.copy(peak = 0f) } }
                        Thread.sleep(40); continue
                    }
                    if (stoppedForPause) { ar.startRecording(); stoppedForPause = false }
                    val n = ar.read(buf, 0, buf.size)
                    if (n < 0) { fail(readError(n)); break }
                    if (n == 0) continue
                    var peak = 0; var clipped = false
                    for (i in 0 until n) {
                        var v = (buf[i] * gain).toInt()
                        if (v > 32767) v = 32767 else if (v < -32768) v = -32768
                        buf[i] = v.toShort()
                        val a = abs(v)
                        if (a > peak) peak = a
                        if (a >= Levels.CLIP_THRESHOLD) clipped = true
                    }
                    queue.put(buf.copyOf(n))
                    capturedFrames += n / ch
                    silent = if (peak == 0) silent + n / ch else 0
                    hold = max(peak / 32768f, hold * 0.85f)
                    if (clipped) clipCount++
                    val warn = if (silent > sr * 3L)
                        "No signal for 3+ seconds. The input may be muted, disconnected, or in use by a call or another app." else null
                    _ui.update {
                        it.copy(elapsedMs = capturedFrames * 1000L / sr, peak = hold, clipped = clipped, clipCount = clipCount,
                            bytesWritten = capturedFrames * ch * 2L, warning = warn)
                    }
                }
            }
        } catch (e: Exception) {
            fail("Recording stopped unexpectedly: ${e.message ?: "audio error"}. Audio captured so far was saved.")
        } finally {
            runCatching { ar.removeOnRoutingChangedListener(listener) }
            runCatching { ar.stop() }
            ar.release()
            queue.put(poison)
            writer.join(20_000)
            if (btActive) BluetoothRoute.release(ctx)
            finalizeSegments(segs, sr)
            writeError.get()?.let { m -> _ui.update { it.copy(message = m) } }
            transition(RecEvent.STOP)
            transition(RecEvent.STOPPED)
        }
    }

    private fun finalizeSegments(segs: List<Seg>, sr: Int) {
        segs.forEachIndexed { idx, seg ->
            val f = File(repo.dir, seg.meta.fileName)
            val frames = seg.writer.frames
            val startMs = seg.startFrame * 1000L / sr
            val endMs = startMs + frames * 1000L / sr
            val last = idx == segs.lastIndex
            val mk = markers.filter { it.timeMs >= startMs && (it.timeMs < endMs || last) }
                .map { Marker((it.timeMs - startMs).coerceAtLeast(0), it.label) }
            repo.update(seg.meta.id) {
                it.copy(durationMs = frames * 1000L / sr, sizeBytes = f.length(), status = RecStatus.COMPLETE, markers = mk)
            }
        }
        _ui.update { it.copy(savedCount = segs.size) }
        if (segs.isEmpty() && _ui.value.message == null) _ui.update { it.copy(message = "Nothing was recorded.") }
    }
}
