package com.motovox.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.motovox.app.data.RecordingRepository
import com.motovox.app.data.SettingsStore
import com.motovox.app.recording.RecorderEngine
import com.motovox.app.recording.RecordingService

class MotoVoxApp : Application() {
    lateinit var repo: RecordingRepository
    lateinit var settings: SettingsStore
    lateinit var recorder: RecorderEngine

    override fun onCreate() {
        super.onCreate()
        repo = RecordingRepository(this)
        settings = SettingsStore(this)
        recorder = RecorderEngine(this, repo)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(RecordingService.CHANNEL_ID, getString(R.string.channel_recording), NotificationManager.IMPORTANCE_LOW))
        // Repair recordings left half-written if the process was killed mid-recording.
        Thread { if (!recorder.isActive()) repo.recoverInterrupted() }.start()
    }
}
