package com.motovox.app.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/** One sample in, one sample out. Stages are stateful and must be used on a single stream. */
fun interface Stage { fun process(x: Float): Float }

class Biquad private constructor(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) : Stage {
    private val c0 = b0 / a0; private val c1 = b1 / a0; private val c2 = b2 / a0
    private val d1 = a1 / a0; private val d2 = a2 / a0
    private var z1 = 0.0; private var z2 = 0.0

    override fun process(x: Float): Float {
        val y = c0 * x + z1
        z1 = c1 * x - d1 * y + z2
        z2 = c2 * x - d2 * y
        return y.toFloat()
    }

    companion object {
        private fun w(sr: Int, f: Float) = 2.0 * PI * f.coerceIn(10f, sr * 0.45f) / sr
        fun highPass(sr: Int, f: Float, q: Double = 0.7071): Biquad {
            val w0 = w(sr, f); val c = cos(w0); val al = sin(w0) / (2 * q)
            return Biquad((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
        }
        fun lowPass(sr: Int, f: Float, q: Double = 0.7071): Biquad {
            val w0 = w(sr, f); val c = cos(w0); val al = sin(w0) / (2 * q)
            return Biquad((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
        }
        fun peaking(sr: Int, f: Float, gainDb: Float, q: Double = 1.0): Biquad {
            val w0 = w(sr, f); val c = cos(w0); val al = sin(w0) / (2 * q); val a = 10.0.pow(gainDb / 40.0)
            return Biquad(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
        }
    }
}

class Gain(db: Float) : Stage {
    private val g = 10f.pow(db / 20f)
    override fun process(x: Float) = x * g
}

/** Feed-forward compressor with envelope follower. */
class Compressor(sr: Int, private val thresholdDb: Float, private val ratio: Float,
                 attackMs: Float, releaseMs: Float, makeupDb: Float) : Stage {
    private var env = 0f
    private val aC = exp(-1.0 / (sr * attackMs / 1000.0)).toFloat()
    private val rC = exp(-1.0 / (sr * releaseMs / 1000.0)).toFloat()
    private val thrLin = 10f.pow(thresholdDb / 20f)
    private val makeup = 10f.pow(makeupDb / 20f)

    override fun process(x: Float): Float {
        val a = abs(x)
        env = if (a > env) aC * env + (1 - aC) * a else rC * env + (1 - rC) * a
        if (env <= thrLin) return x * makeup
        val over = 20f * log10(env) - thresholdDb
        return x * makeup * 10f.pow(-over * (1f - 1f / ratio) / 20f)
    }
}

/** Instant-attack peak limiter: output never exceeds ceiling. */
class Limiter(sr: Int, ceilingDb: Float = -0.5f, releaseMs: Float = 120f) : Stage {
    private val ceiling = 10f.pow(ceilingDb / 20f)
    private val rel = 1f - exp(-1.0 / (sr * releaseMs / 1000.0)).toFloat()
    private var g = 1f

    override fun process(x: Float): Float {
        val a = abs(x)
        val target = if (a * g > ceiling) ceiling / a else 1f
        g = if (target < g) target else g + (target - g) * rel
        return (x * g).coerceIn(-ceiling, ceiling)
    }
}

/** Light downward expander: lowers the level between phrases. It does not remove noise that is present while you talk. */
class NoiseGate(sr: Int, thresholdDb: Float = -48f, floorDb: Float = -12f) : Stage {
    private val thr = 10f.pow(thresholdDb / 20f)
    private val floor = 10f.pow(floorDb / 20f)
    private val aC = exp(-1.0 / (sr * 0.005)).toFloat()
    private val rC = exp(-1.0 / (sr * 0.15)).toFloat()
    private val sm = 1f - exp(-1.0 / (sr * 0.02)).toFloat()
    private var env = 0f; private var g = 1f

    override fun process(x: Float): Float {
        val a = abs(x)
        env = if (a > env) aC * env + (1 - aC) * a else rC * env + (1 - rC) * a
        g += ((if (env > thr) 1f else floor) - g) * sm
        return x * g
    }
}

class Echo(sr: Int, delayMs: Float, private val feedback: Float, private val mix: Float) : Stage {
    private val buf = FloatArray(max(1, (sr * delayMs / 1000f).toInt()))
    private var i = 0
    override fun process(x: Float): Float {
        val d = buf[i]
        buf[i] = x + d * feedback
        i = (i + 1) % buf.size
        return x + d * mix
    }
}

/** Schroeder reverb: 4 damped combs + 2 all-passes. */
class Reverb(sr: Int, size: Float, private val mix: Float) : Stage {
    private val scale = sr / 44100f
    private val combLen = intArrayOf(1557, 1617, 1491, 1422).map { (it * scale).toInt().coerceAtLeast(8) }
    private val combs = combLen.map { FloatArray(it) }
    private val combIdx = IntArray(4)
    private val combStore = FloatArray(4)
    private val fb = 0.70f + 0.25f * size.coerceIn(0f, 1f)
    private val damp = 0.25f
    private val apLen = intArrayOf(225, 556).map { (it * scale).toInt().coerceAtLeast(8) }
    private val aps = apLen.map { FloatArray(it) }
    private val apIdx = IntArray(2)

    override fun process(x: Float): Float {
        var sum = 0f
        for (c in 0 until 4) {
            val b = combs[c]; val y = b[combIdx[c]]
            combStore[c] = y * (1 - damp) + combStore[c] * damp
            b[combIdx[c]] = x * 0.3f + combStore[c] * fb
            combIdx[c] = (combIdx[c] + 1) % b.size
            sum += y
        }
        var s = sum * 0.25f
        for (a in 0 until 2) {
            val b = aps[a]; val d = b[apIdx[a]]
            val out = -s + d
            b[apIdx[a]] = s + d * 0.5f
            apIdx[a] = (apIdx[a] + 1) % b.size
            s = out
        }
        return x * (1 - mix * 0.5f) + s * mix * 1.6f
    }
}

class RingMod(private val sr: Int, private val freq: Float, private val mix: Float) : Stage {
    private var phase = 0.0
    override fun process(x: Float): Float {
        phase += 2 * PI * freq / sr; if (phase > 2 * PI) phase -= 2 * PI
        return x * (1 - mix) + x * sin(phase).toFloat() * mix
    }
}

class SoftClip(private val drive: Float) : Stage {
    private val norm = tanh(drive)
    override fun process(x: Float) = tanh(x * drive) / norm
}

/**
 * Time-domain granular pitch shifter: two read taps sweep through a delay line and are cross-faded with a
 * sin^2 window (the two weights always sum to 1). Reads advance `ratio` samples per output sample.
 * Good for voice at moderate shifts; extreme settings produce audible artefacts.
 */
class PitchShifter(sr: Int, private val ratio: Float, windowMs: Float = 45f) : Stage {
    private val win = (sr * windowMs / 1000f).toInt().coerceAtLeast(64)
    private val buf = FloatArray(win * 2 + 4)
    private var w = 0
    private var phase = 0f

    private fun read(delay: Float): Float {
        var pos = w - delay
        while (pos < 0) pos += buf.size
        val i0 = floor(pos).toInt() % buf.size
        val fr = pos - floor(pos)
        return buf[i0] * (1 - fr) + buf[(i0 + 1) % buf.size] * fr
    }

    override fun process(x: Float): Float {
        buf[w] = x
        val pB = (phase + 0.5f) % 1f
        val sa = sin(PI * phase).toFloat(); val sb = sin(PI * pB).toFloat()
        val out = read(phase * win) * sa * sa + read(pB * win) * sb * sb
        phase += (1f - ratio) / win
        phase -= floor(phase)
        w = (w + 1) % buf.size
        return out
    }
}
