package com.motovox.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

/** Three short 1 kHz beeps played on the phone speaker so both phone and camera microphones capture a common spike. */
object SyncTone {
    fun play() {
        Thread {
            val sr = 44100
            val beep = (sr * 0.15).toInt(); val gap = (sr * 0.35).toInt()
            val pcm = ShortArray((beep + gap) * 3)
            for (b in 0 until 3) for (i in 0 until beep) {
                val env = minOf(1f, i / 200f, (beep - i) / 200f)
                pcm[b * (beep + gap) + i] = (sin(2 * PI * 1000 * i / sr) * 0.6 * env * 32767).toInt().toShort()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
            try {
                track.write(pcm, 0, pcm.size); track.play()
                Thread.sleep(pcm.size * 1000L / sr + 150)
            } finally { track.release() }
        }.apply { isDaemon = true }.start()
    }
}
