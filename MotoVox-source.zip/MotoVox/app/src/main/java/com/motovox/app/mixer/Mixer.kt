package com.motovox.app.mixer

import com.motovox.app.audio.Levels
import com.motovox.app.audio.WavIO
import com.motovox.app.effects.Limiter
import com.motovox.app.effects.OfflineProcessor
import java.io.File
import java.io.IOException
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

data class MixParams(
    val voiceGainDb: Float = 0f,
    val musicGainDb: Float = -14f,
    val musicOffsetMs: Long = 0,
    val trimStartMs: Long = 0,
    val trimEndMs: Long = 0,        // 0 = to end of music
    val loop: Boolean = true,
    val fadeInMs: Long = 2000,
    val fadeOutMs: Long = 3000,
    val duckDb: Float = -8f,        // 0 = no ducking
    val limiter: Boolean = true
)

data class MixPreset(val name: String, val params: MixParams)

object MixPresets {
    val all = listOf(
        MixPreset("Cinematic Ride", MixParams(0f, -16f, 0, 0, 0, true, 4000, 5000, -10f)),
        MixPreset("Travel Vlog", MixParams(0f, -14f, 0, 0, 0, true, 2000, 3000, -8f)),
        MixPreset("Road Adventure", MixParams(0f, -12f, 0, 0, 0, true, 1500, 2500, -6f)),
        MixPreset("Clean Voice", MixParams(1.5f, -22f, 0, 0, 0, true, 1000, 2000, -12f)),
        MixPreset("Minimal Background", MixParams(0f, -26f, 0, 0, 0, true, 3000, 4000, -4f))
    )
}

object MixMath {
    fun fadeGain(pos: Long, startFrame: Long, endFrame: Long, fadeInFrames: Long, fadeOutFrames: Long): Float {
        val fi = if (fadeInFrames > 0) ((pos - startFrame).toFloat() / fadeInFrames).coerceIn(0f, 1f) else 1f
        val fo = if (fadeOutFrames > 0) ((endFrame - pos).toFloat() / fadeOutFrames).coerceIn(0f, 1f) else 1f
        return fi * fo
    }
    fun msToFrames(ms: Long, sr: Int) = ms * sr / 1000L
}

private class MusicSource(private val rd: WavIO.Reader, private val startF: Long, private val endF: Long, private val loop: Boolean) {
    private val ch = rd.info.channels
    private val buf = ShortArray(4096 * ch)
    private var len = 0; private var pos = 0; private var posF = startF
    private var finished = false
    init { rd.seekFrame(startF) }

    fun next(): Float {
        if (finished) return 0f
        if (pos >= len && !refill()) return 0f
        var m = 0f
        for (c in 0 until ch) m += buf[pos++]
        return m / (ch * 32768f)
    }

    private fun refill(): Boolean {
        repeat(2) {
            if (posF >= endF) { if (!loop) { finished = true; return false }; rd.seekFrame(startF); posF = startF }
            val n = rd.read(buf, min(buf.size.toLong(), (endF - posF) * ch).toInt())
            if (n > 0) { len = n; pos = 0; posF += n / ch; return true }
            posF = endF
        }
        finished = true
        return false
    }
}

object Mixer {
    /** Mixes `voice` with optional decoded music (mono WAV at the same sample rate) into a new mono WAV. Output length = voice length. */
    fun mix(
        voice: File, music: File?, dst: File, p: MixParams, maxSeconds: Float = 0f,
        onProgress: (Float) -> Unit = {}, cancelled: () -> Boolean = { false }
    ): OfflineProcessor.Result {
        val vr = try { WavIO.Reader(voice) } catch (e: IOException) { return OfflineProcessor.Result(false, 0, e.message) }
        val mr: WavIO.Reader? = if (music == null) null else try { WavIO.Reader(music) } catch (e: IOException) {
            vr.close(); return OfflineProcessor.Result(false, 0, "Music file unreadable: ${e.message}")
        }
        try {
            val sr = vr.info.sampleRate; val vch = vr.info.channels
            var src: MusicSource? = null
            if (mr != null) {
                if (mr.info.sampleRate != sr) return OfflineProcessor.Result(false, 0, "Music sample rate doesn't match the voice track.")
                val s = MixMath.msToFrames(p.trimStartMs, sr).coerceIn(0, mr.info.frames)
                val e = if (p.trimEndMs > 0) MixMath.msToFrames(p.trimEndMs, sr).coerceAtMost(mr.info.frames) else mr.info.frames
                if (e - s < sr / 10) return OfflineProcessor.Result(false, 0, "The music trim range is empty. Move the trim points apart.")
                src = MusicSource(mr, s, e, p.loop)
            }
            val music0: MusicSource? = src
            val musicStartFrame = MixMath.msToFrames(p.musicOffsetMs, sr)
            val total = if (maxSeconds > 0) min(vr.info.frames, (maxSeconds * sr).toLong()) else vr.info.frames
            val vg = Levels.dbToLinear(p.voiceGainDb); val mg = Levels.dbToLinear(p.musicGainDb)
            val duckLin = Levels.dbToLinear(p.duckDb)
            val atk = 1f - exp(-1.0 / (sr * 0.05)).toFloat(); val rel = 1f - exp(-1.0 / (sr * 0.4)).toFloat()
            val envA = exp(-1.0 / (sr * 0.01)).toFloat(); val envR = exp(-1.0 / (sr * 0.2)).toFloat()
            val lim = Limiter(sr, -1f)
            val fi = MixMath.msToFrames(p.fadeInMs, sr); val fo = MixMath.msToFrames(p.fadeOutMs, sr)
            var env = 0f; var duck = 1f
            val inBuf = ShortArray(sr / 10 * vch); val out = ShortArray(sr / 10)
            var done = 0L
            WavIO.Writer(dst, sr, 1).use { w ->
                while (done < total) {
                    if (cancelled()) return OfflineProcessor.Result(false, done, "Cancelled")
                    val n = vr.read(inBuf, min(inBuf.size.toLong(), (total - done) * vch).toInt())
                    if (n <= 0) break
                    val frames = n / vch
                    for (f in 0 until frames) {
                        var v = 0f
                        for (c in 0 until vch) v += inBuf[f * vch + c]
                        v = v / (vch * 32768f) * vg
                        val g = done + f
                        var m = 0f
                        if (music0 != null && g >= musicStartFrame) {
                            val raw = music0.next()
                            val a = abs(v)
                            env = if (a > env) envA * env + (1 - envA) * a else envR * env + (1 - envR) * a
                            val target = if (p.duckDb < 0f && env > 0.02f) duckLin else 1f
                            duck += (target - duck) * (if (target < duck) atk else rel)
                            m = raw * mg * duck * MixMath.fadeGain(g, musicStartFrame, total, fi, fo)
                        }
                        val mixed = v + m
                        out[f] = OfflineProcessor.toShort(if (p.limiter) lim.process(mixed) else mixed)
                    }
                    w.write(out, frames); done += frames
                    onProgress(done.toFloat() / total)
                }
            }
            return OfflineProcessor.Result(true, done, null)
        } catch (e: IOException) {
            return OfflineProcessor.Result(false, 0, "Disk error: ${e.message}")
        } finally { vr.close(); mr?.close() }
    }
}
