package com.motovox.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motovox.app.audio.InputKind
import com.motovox.app.audio.Levels
import com.motovox.app.data.Naming
import com.motovox.app.permissions.Perms
import com.motovox.app.recording.Estimates
import com.motovox.app.recording.RecState

@Composable
fun RecordScreen(vm: MainViewModel, onMicTest: () -> Unit) {
    val ctx = LocalContext.current
    val rec by vm.rec.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val inputs by vm.inputs.collectAsStateWithLifecycle()
    var project by rememberSaveable { mutableStateOf("") }
    var rationale by remember { mutableStateOf<List<String>?>(null) }
    var menu by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    val selected = inputs.firstOrNull { it.id == s.deviceId }
    val needsBt = selected?.kind == InputKind.BLUETOOTH
    val idle = rec.state == RecState.IDLE || rec.state == RecState.ERROR
    val micOk = remember(tick) { Perms.hasMic(ctx) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        tick++
        if (res.any { (p, ok) -> !ok && Perms.blocking(p) })
            vm.notice.value = "MotoVox can't record without microphone permission (and Bluetooth permission for a Bluetooth mic). You can grant it from Settings → Permission diagnostics."
        else vm.startRecording(ctx, project)
    }
    fun tryStart() {
        val miss = Perms.missing(ctx, needsBt)
        if (miss.isEmpty()) vm.startRecording(ctx, project) else rationale = miss
    }

    rationale?.let { miss ->
        AlertDialog(
            onDismissRequest = { rationale = null },
            title = { Text("Permissions needed") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    miss.forEach { p ->
                        Text(when {
                            p.endsWith("RECORD_AUDIO") -> "• Microphone: to record your voice."
                            p.endsWith("POST_NOTIFICATIONS") -> "• Notifications: to show recording status with a Stop button."
                            p.endsWith("BLUETOOTH_CONNECT") -> "• Nearby devices: to use your Bluetooth microphone."
                            else -> "• $p"
                        })
                    }
                    Text("Recordings stay on this phone. MotoVox never uploads audio.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { rationale = null; launcher.launch(miss.toTypedArray()) }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { rationale = null }) { Text("Not now") } }
        )
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Wordmark(); Spacer(Modifier.weight(1f))
            TextButton(onClick = onMicTest) { Text("Mic test") }
        }

        rec.message?.let { Banner(it, isError = true) { vm.dismissRecError() } }
        rec.warning?.let { Banner(it, isError = true) }
        if (idle && rec.savedCount > 0 && rec.message == null)
            Banner("Saved ${rec.savedCount} recording${if (rec.savedCount > 1) "s" else ""} to your Library.")

        SectionCard("Input") {
            val ready = micOk && (s.deviceId < 0 || selected != null)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(
                    when { rec.state == RecState.RECORDING -> MV.Red; ready -> MV.Green; else -> MV.Grey }))
                Spacer(Modifier.width(8.dp))
                Text(when (rec.state) {
                    RecState.RECORDING -> "Recording"; RecState.PAUSED -> "Paused"
                    RecState.PREPARING -> "Starting…"; RecState.STOPPING -> "Saving…"
                    else -> when {
                        !micOk -> "Microphone permission needed"
                        s.deviceId >= 0 && selected == null -> "Selected input unavailable — Android's default will be used"
                        else -> "Ready"
                    }
                }, fontWeight = FontWeight.SemiBold)
            }
            if (idle) {
                Box {
                    OutlinedButton(onClick = { menu = true }, Modifier.fillMaxWidth()) {
                        Text(selected?.let { "${it.name} — ${it.typeLabel}" } ?: "Automatic (Android default)", Modifier.weight(1f), maxLines = 1)
                        Icon(Icons.Filled.KeyboardArrowDown, null)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Automatic (Android default)") }, onClick = { vm.setDevice(-1); menu = false })
                        inputs.forEach { d ->
                            DropdownMenuItem(
                                text = { Column { Text(d.name); Text(d.typeLabel, style = MaterialTheme.typography.bodySmall) } },
                                onClick = { vm.setDevice(d.id); menu = false })
                        }
                    }
                }
                if (needsBt) Text("Bluetooth mics use a low-bandwidth voice profile, so quality will be lower than wired or USB. Not every headset or intercom works as a recording mic.",
                    style = MaterialTheme.typography.bodySmall, color = MV.Amber)
            } else {
                Text(rec.routeName.ifEmpty { "Detecting input…" })
            }
            rec.routeNote?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MV.Amber) }
        }

        SectionCard("Level") {
            LevelMeter(rec.peak)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val active = rec.state == RecState.RECORDING
                Text(if (active) "%.0f dBFS".format(Levels.peakToDb(rec.peak)) else "—", fontFamily = FontFamily.Monospace)
                if (rec.clipCount > 0) Text("Clipped ${rec.clipCount}× — lower the mic level", color = MV.Red, style = MaterialTheme.typography.bodySmall)
            }
        }

        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(Naming.formatTime(rec.elapsedMs), fontSize = 56.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Text("WAV • ${"%.1f".format(s.sampleRate / 1000.0)} kHz • ${if (s.channels == 2) "Stereo" else "Mono"} • software gain ${"%.0f".format(s.gainDb)} dB",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!idle) Text("${formatBytes(rec.bytesWritten)} written", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            else {
                val hrs = Estimates.minutesAvailable(vm.freeBytes(), s.sampleRate, s.channels) / 60.0
                Text("≈ ${formatBytes(Estimates.bytesPerHour(s.sampleRate, s.channels))}/hour • room for ~${"%.1f".format(hrs)} h",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        OutlinedTextField(
            value = project, onValueChange = { project = it.take(60) }, enabled = idle, singleLine = true,
            label = { Text("Project / ride name") },
            placeholder = { Text(Naming.defaultProject(s.projectPrefix, System.currentTimeMillis())) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(16.dp))

        when (rec.state) {
            RecState.IDLE, RecState.ERROR -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Button(onClick = { tryStart() }, shape = CircleShape, modifier = Modifier.size(112.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MV.Red, contentColor = MV.White)) {
                    Icon(Icons.Filled.FiberManualRecord, "Start recording", Modifier.size(64.dp))
                }
                Spacer(Modifier.height(6.dp)); Text("Start recording", fontWeight = FontWeight.SemiBold)
            }
            RecState.PREPARING, RecState.STOPPING -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            RecState.RECORDING, RecState.PAUSED -> Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val isPaused = rec.state == RecState.PAUSED
                FilledTonalButton(onClick = { if (isPaused) vm.resumeRecording() else vm.pauseRecording() },
                    Modifier.weight(1f).height(64.dp)) {
                    Icon(if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause, null)
                    Spacer(Modifier.width(8.dp)); Text(if (isPaused) "Resume" else "Pause")
                }
                Button(onClick = { vm.stopRecording() }, Modifier.weight(1f).height(64.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MV.Red, contentColor = MV.White)) {
                    Icon(Icons.Filled.Stop, null); Spacer(Modifier.width(8.dp)); Text("Stop")
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        val canMark = rec.state == RecState.RECORDING || rec.state == RecState.PAUSED
        Button(onClick = { vm.addMarker() }, enabled = canMark,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(72.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MV.Green, contentColor = MV.Black)) {
            Icon(Icons.Filled.Flag, null); Spacer(Modifier.width(8.dp)); Text("MARK THIS MOMENT", fontWeight = FontWeight.Bold)
        }
        if (rec.markers.isNotEmpty()) SectionCard("Markers (${rec.markers.size})") {
            rec.markers.takeLast(5).reversed().forEach { Text("${Naming.formatTime(it.timeMs)}  ${it.label}", fontFamily = FontFamily.Monospace) }
        }

        SectionCard("Before you ride") {
            Text("Set up your microphone, level and project name while stopped. Don't operate your phone while riding. " +
                "With the screen off, a notification keeps recording visible and has Pause, Mark and Stop. " +
                "MotoVox can't guarantee uninterrupted recording on every phone — check battery-optimization settings and do a short test first.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
