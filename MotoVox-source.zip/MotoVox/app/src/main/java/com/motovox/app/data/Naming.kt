package com.motovox.app.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Naming {
    fun sanitize(s: String): String =
        s.trim().replace(Regex("[^A-Za-z0-9 _-]"), "").replace(Regex("\\s+"), "_").take(40).ifEmpty { "MotoVox" }

    fun fileName(project: String, timestamp: Long, suffix: String, ext: String = "wav",
                 zone: TimeZone = TimeZone.getDefault()): String {
        val f = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).apply { timeZone = zone }
        val tail = if (suffix.isBlank()) "" else "_" + sanitize(suffix)
        return "${sanitize(project)}_${f.format(Date(timestamp))}$tail.$ext"
    }

    fun defaultProject(prefix: String, timestamp: Long, zone: TimeZone = TimeZone.getDefault()): String {
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = zone }
        return "${prefix.trim().ifEmpty { "Ride" }} ${f.format(Date(timestamp))}"
    }

    fun formatTime(ms: Long, withMillis: Boolean = false): String {
        val t = ms.coerceAtLeast(0)
        val h = t / 3_600_000; val m = (t / 60_000) % 60; val s = (t / 1000) % 60
        val base = if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
        return if (withMillis) base + ".%03d".format(t % 1000) else base
    }
}
