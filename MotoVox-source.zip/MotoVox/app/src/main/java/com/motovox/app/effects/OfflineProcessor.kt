package com.motovox.app.effects

import com.motovox.app.audio.WavIO
import java.io.File
import java.io.IOException

/** Streams a WAV through a stage chain into a new mono WAV. The source file is never modified. */
object OfflineProcessor {
    data class Result(val ok: Boolean, val frames: Long, val error: String?)

    fun toShort(v: Float): Short = (v * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()

    fun run(
        src: File, dst: File, stages: Array<Stage>, tailSec: Float, maxSeconds: Float = 0f,
        onProgress: (Float) -> Unit = {}, cancelled: () -> Boolean = { false }
    ): Result {
        val rd = try { WavIO.Reader(src) } catch (e: IOException) { return Result(false, 0, e.message) }
        return try {
            rd.use {
                val sr = rd.info.sampleRate; val ch = rd.info.channels
                val inBuf = ShortArray(sr / 10 * ch); val outBuf = ShortArray(sr / 10)
                val total = if (maxSeconds > 0) minOf(rd.info.frames, (maxSeconds * sr).toLong()) else rd.info.frames
                var done = 0L
                WavIO.Writer(dst, sr, 1).use { w ->
                    while (done < total) {
                        if (cancelled()) return Result(false, done, "Cancelled")
                        val n = rd.read(inBuf, minOf(inBuf.size.toLong(), (total - done) * ch).toInt())
                        if (n <= 0) break
                        val frames = n / ch
                        for (f in 0 until frames) {
                            var m = 0f
                            for (c in 0 until ch) m += inBuf[f * ch + c]
                            var x = m / (ch * 32768f)
                            for (st in stages) x = st.process(x)
                            outBuf[f] = toShort(x)
                        }
                        w.write(outBuf, frames); done += frames
                        onProgress(done.toFloat() / total * 0.95f)
                    }
                    var t = (tailSec * sr).toInt()
                    while (t > 0 && !cancelled()) {
                        val k = minOf(t, outBuf.size)
                        for (i in 0 until k) { var x = 0f; for (st in stages) x = st.process(x); outBuf[i] = toShort(x) }
                        w.write(outBuf, k); t -= k
                    }
                }
                onProgress(1f)
                Result(true, done, null)
            }
        } catch (e: IOException) { Result(false, 0, "Disk error: ${e.message}") }
    }
}
