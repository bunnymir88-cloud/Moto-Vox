package com.motovox.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motovox.app.data.Naming
import com.motovox.app.data.RecStatus
import com.motovox.app.data.RecordingKind
import com.motovox.app.effects.EqPreset
import com.motovox.app.effects.VoiceEffect
import kotlinx.coroutines.flow.update

@Composable
fun VoiceFxScreen(vm: MainViewModel) {
    val ui by vm.fxUi.collectAsStateWithLifecycle()
    val recs by vm.recordings.collectAsStateWithLifecycle()
    val playing by vm.playingKey.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    val usable = recs.filter { it.kind != RecordingKind.MIX && it.status != RecStatus.RECORDING }.sortedByDescending { it.createdAt }
    val src = usable.firstOrNull { it.id == ui.sourceId }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(usable.size) { if (ui.sourceId == null || src == null) vm.fxUi.update { it.copy(sourceId = usable.firstOrNull()?.id) } }
    val e = ui.enhance

    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        Text("Voice FX Studio", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.headlineSmall)

        SectionCard("Recording") {
            if (usable.isEmpty()) Text("No recordings yet. Record something first, then come back to enhance it or change your voice.")
            else Box {
                OutlinedButton(onClick = { menu = true }, Modifier.fillMaxWidth()) {
                    Text(src?.let { "${it.name} • ${Naming.formatTime(it.durationMs)}" } ?: "Choose recording", Modifier.weight(1f), maxLines = 1)
                    Icon(Icons.Filled.KeyboardArrowDown, null)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    usable.forEach { m ->
                        DropdownMenuItem(text = { Text("${m.name} • ${Naming.formatTime(m.durationMs)}") },
                            onClick = { vm.fxUi.update { it.copy(sourceId = m.id) }; menu = false })
                    }
                }
            }
            Text("Your original is never changed. Results are saved as new mono WAV recordings.", style = MaterialTheme.typography.bodySmall)
        }

        SectionCard("Voice effect") {
            VoiceEffect.values().toList().chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { fx ->
                        FilterChip(selected = ui.fx.effect == fx, onClick = { vm.fxUi.update { it.copy(fx = it.fx.copy(effect = fx)) } },
                            label = { Text(fx.label) }, modifier = Modifier.weight(1f))
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Text(ui.fx.effect.blurb, style = MaterialTheme.typography.bodySmall)
            if (ui.fx.effect != VoiceEffect.ORIGINAL)
                LabeledSlider(if (ui.fx.effect == VoiceEffect.CUSTOM) "Echo amount" else "Intensity", ui.fx.intensity, 0f..1f, "${(ui.fx.intensity * 100).toInt()}%") { v ->
                    vm.fxUi.update { it.copy(fx = it.fx.copy(intensity = v)) } }
            if (ui.fx.effect == VoiceEffect.CUSTOM)
                LabeledSlider("Pitch", ui.fx.customSemitones, -12f..12f, "%+.1f semitones".format(ui.fx.customSemitones)) { v ->
                    vm.fxUi.update { it.copy(fx = it.fx.copy(customSemitones = v)) } }
            Text("Pitch effects use a granular time-domain shifter (not simple speed change). It keeps the length but can sound artificial at extreme settings.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Clean-up (applied before the effect)") {
            LabeledSlider("Software gain", e.gainDb, -12f..12f, "%+.0f dB".format(e.gainDb), steps = 23) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(gainDb = v)) } }
            SwitchRow("High-pass filter", "Reduces engine and handling rumble", e.highPass) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(highPass = v)) } }
            if (e.highPass) LabeledSlider("Cut-off", e.hpfHz, 60f..200f, "${e.hpfHz.toInt()} Hz") { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(hpfHz = v)) } }
            SwitchRow("Wind-rumble filter", "Steeper low cut at 160 Hz. Reduces low-frequency wind thump; it cannot remove wind noise that overlaps speech.", e.windFilter) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(windFilter = v)) } }
            SwitchRow("Light noise gate", "Lowers background between phrases. It doesn't clean noise while you talk.", e.gate) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(gate = v)) } }
            Text("Tone")
            ChipRow(EqPreset.values().map { it.label to it }, e.eq) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(eq = v)) } }
            SwitchRow("Gentle compression", "Evens out loud and quiet speech", e.compressor) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(compressor = v)) } }
            SwitchRow("Peak limiter", "Prevents clipping on the output", e.limiter) { v -> vm.fxUi.update { it.copy(enhance = it.enhance.copy(limiter = v)) } }
        }

        SectionCard("Preview & save") {
            val busy = job.running
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::previewOriginal, enabled = src != null && !busy, modifier = Modifier.weight(1f)) {
                    Text(if (playing == "fx-orig") "Stop" else "Play original") }
                OutlinedButton(onClick = { if (playing == "fx-proc") vm.stopPlayback() else vm.previewProcessed() },
                    enabled = src != null && !busy, modifier = Modifier.weight(1f)) {
                    Text(if (playing == "fx-proc") "Stop" else "Play processed") }
            }
            Text("Processed preview covers the first 12 seconds so you can compare quickly.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = vm::applyFx, enabled = src != null && !busy, modifier = Modifier.fillMaxWidth()) { Text("Save as new recording") }
        }
    }
}
