package com.motovox.app.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

enum class InputKind { BUILTIN, WIRED, USB, BLUETOOTH, OTHER }

data class InputDevice(
    val id: Int, val name: String, val typeLabel: String, val kind: InputKind,
    val sampleRates: List<Int>, val channelCounts: List<Int>
)

object AudioDevices {
    private const val TYPE_BLE_HEADSET = 26 // AudioDeviceInfo.TYPE_BLE_HEADSET (API 31)

    fun classify(type: Int): InputKind = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> InputKind.BUILTIN
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL -> InputKind.WIRED
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> InputKind.USB
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, TYPE_BLE_HEADSET -> InputKind.BLUETOOTH
        else -> InputKind.OTHER
    }

    fun label(kind: InputKind, type: Int): String = when (kind) {
        InputKind.BUILTIN -> "Built-in microphone"
        InputKind.WIRED -> "Wired headset / line input"
        InputKind.USB -> "USB audio input"
        InputKind.BLUETOOTH -> "Bluetooth (voice profile, reduced quality)"
        InputKind.OTHER -> "Other input (type $type)"
    }

    private fun am(ctx: Context) = ctx.getSystemService(AudioManager::class.java)

    fun list(ctx: Context): List<InputDevice> =
        am(ctx).getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.isSource }.map { d ->
            val kind = classify(d.type)
            val product = d.productName?.toString()?.takeIf { it.isNotBlank() }
            InputDevice(d.id, product ?: label(kind, d.type), label(kind, d.type), kind,
                d.sampleRates.toList(), d.channelCounts.toList())
        }.sortedBy { it.kind.ordinal }

    fun find(ctx: Context, id: Int): AudioDeviceInfo? =
        if (id < 0) null else am(ctx).getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.id == id }

    fun isBluetooth(d: AudioDeviceInfo) = classify(d.type) == InputKind.BLUETOOTH
}

/** Routes the communication audio path to a Bluetooth headset. Only used when the rider explicitly selects one. */
object BluetoothRoute {
    @Suppress("DEPRECATION")
    fun activate(ctx: Context, device: AudioDeviceInfo): Boolean {
        val am = ctx.getSystemService(AudioManager::class.java)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val target = am.availableCommunicationDevices.firstOrNull {
                    it.id == device.id || (it.type == device.type && it.address == device.address)
                } ?: return false
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.setCommunicationDevice(target)
            } else {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.startBluetoothSco(); am.isBluetoothScoOn = true; true
            }
        } catch (e: SecurityException) { false }
    }

    @Suppress("DEPRECATION")
    fun release(ctx: Context) {
        val am = ctx.getSystemService(AudioManager::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.clearCommunicationDevice()
            else { am.stopBluetoothSco(); am.isBluetoothScoOn = false }
            am.mode = AudioManager.MODE_NORMAL
        }
    }
}
