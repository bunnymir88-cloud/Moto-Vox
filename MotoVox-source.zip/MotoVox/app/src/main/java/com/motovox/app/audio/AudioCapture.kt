package com.motovox.app.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.motovox.app.permissions.Perms

object AudioCapture {
    data class Opened(val record: AudioRecord?, val error: String?)

    fun open(ctx: Context, sampleRate: Int, channels: Int, device: AudioDeviceInfo?, bufferMs: Int = 400): Opened {
        if (!Perms.hasMic(ctx)) return Opened(null, "Microphone permission is not granted.")
        val mask = if (channels == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO
        val min = AudioRecord.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return Opened(null,
            "This input can't capture $sampleRate Hz ${if (channels == 2) "stereo" else "mono"}. Try mono or another sample rate in Settings.")
        val bytes = maxOf(min * 2, sampleRate * channels * 2 * bufferMs / 1000)
        val source = if (device != null && AudioDevices.isBluetooth(device))
            MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
        return try {
            val ar = AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(mask).build())
                .setBufferSizeInBytes(bytes).build()
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return Opened(null, "Android couldn't start the audio input. Another app may be using the microphone.")
            }
            if (device != null) ar.setPreferredDevice(device)
            Opened(ar, null)
        } catch (e: SecurityException) {
            Opened(null, "Microphone permission was denied by Android.")
        } catch (e: Exception) {
            Opened(null, "Couldn't open the audio input: ${e.message ?: "unknown error"}")
        }
    }
}

/** Level math shared by recorder, mic test and tests. */
object Levels {
    const val CLIP_THRESHOLD = 32440 // ~ -0.1 dBFS
    fun peakToDb(peak: Float): Float = if (peak <= 1e-6f) -120f else 20f * kotlin.math.log10(peak)
    fun dbToFraction(db: Float, floorDb: Float = -60f): Float = ((db - floorDb) / -floorDb).coerceIn(0f, 1f)
    fun dbToLinear(db: Float): Float = Math.pow(10.0, db / 20.0).toFloat()
}
