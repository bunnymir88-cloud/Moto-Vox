package com.motovox.app.mixer

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import com.motovox.app.audio.WavIO
import java.io.File
import java.nio.ByteOrder

class LinearResampler(srcRate: Int, dstRate: Int) {
    private val step = srcRate.toDouble() / dstRate
    private var pos = 0.0
    private var prev = 0f
    private var started = false

    fun feed(x: Float, out: (Float) -> Unit) {
        if (!started) { prev = x; started = true; return }
        while (pos < 1.0) { out(prev + (x - prev) * pos.toFloat()); pos += step }
        pos -= 1.0
        prev = x
    }
}

/** Decodes any Android-supported audio file (MP3/AAC/WAV/...) to a mono 16-bit WAV at `targetSr`, streaming. */
object MusicDecoder {
    data class Probe(val name: String, val durationMs: Long)

    fun probe(ctx: Context, uri: Uri): Pair<Probe?, String?> {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(ctx, uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    val dur = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) / 1000 else 0L
                    return Probe(displayName(ctx, uri), dur) to null
                }
            }
            null to "That file has no audio track MotoVox can read."
        } catch (e: Exception) {
            null to "Couldn't open that file as audio (${e.message ?: "unsupported format"})."
        } finally { ex.release() }
    }

    private fun displayName(ctx: Context, uri: Uri): String = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "Music"
    } catch (e: Exception) { "Music" }

    /** Returns an error message, or null on success. */
    fun decode(ctx: Context, uri: Uri, dst: File, targetSr: Int,
               onProgress: (Float) -> Unit, cancelled: () -> Boolean): String? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1; var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) return "That file has no audio track MotoVox can read."
            ex.selectTrack(idx)
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0); codec.start()

            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var rs = LinearResampler(fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE), targetSr)
            var isFloat = false
            val info = MediaCodec.BufferInfo()
            val tmp = ShortArray(8192); var tmpN = 0
            var inDone = false; var outDone = false
            var written = 0L

            WavIO.Writer(dst, targetSr, 1).use { w ->
                val emit = { x: Float ->
                    tmp[tmpN++] = (x * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
                    if (tmpN == tmp.size) { w.write(tmp, tmpN); written += tmpN; tmpN = 0 }
                }
                while (!outDone) {
                    if (cancelled()) return "Cancelled"
                    if (!inDone) {
                        val ii = codec.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val n = ex.readSampleData(codec.getInputBuffer(ii)!!, 0)
                            if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                            else { codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val oi = codec.dequeueOutputBuffer(info, 10_000)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val of = codec.outputFormat
                        ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        rs = LinearResampler(of.getInteger(MediaFormat.KEY_SAMPLE_RATE), targetSr)
                        isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    } else if (oi >= 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset); ob.limit(info.offset + info.size); ob.order(ByteOrder.LITTLE_ENDIAN)
                        var acc = 0f; var c = 0
                        val count = if (isFloat) info.size / 4 else info.size / 2
                        val fb = if (isFloat) ob.asFloatBuffer() else null
                        val sb = if (!isFloat) ob.asShortBuffer() else null
                        for (k in 0 until count) {
                            acc += if (fb != null) fb.get() else sb!!.get() / 32768f
                            if (++c == ch) { rs.feed(acc / ch, emit); acc = 0f; c = 0 }
                        }
                        if (durUs > 0) onProgress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                        codec.releaseOutputBuffer(oi, false)
                    }
                }
                if (tmpN > 0) { w.write(tmp, tmpN); written += tmpN }
            }
            return if (written == 0L) "No audio could be decoded from that file." else null
        } catch (e: Exception) {
            return "Couldn't decode that file: ${e.message ?: "unsupported or damaged audio"}"
        } finally {
            runCatching { codec?.stop() }; runCatching { codec?.release() }; ex.release()
        }
    }
}
