package com.motovox.app.recording

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.motovox.app.MainActivity
import com.motovox.app.MotoVoxApp
import com.motovox.app.R
import com.motovox.app.data.Naming
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Foreground service (type: microphone) that keeps the process alive and visible while recording. Audio work lives in RecorderEngine. */
class RecordingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var watchJob: Job? = null
    private val app get() = application as MotoVoxApp

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val rec = app.recorder
        when (intent?.action) {
            ACTION_START -> {
                val project = intent?.getStringExtra(EXTRA_PROJECT) ?: "MotoVox"
                val device = intent?.getIntExtra(EXTRA_DEVICE, -1) ?: -1
                try {
                    enterForeground(buildNotification(RecState.PREPARING, 0, project))
                } catch (e: Exception) {
                    rec.reportError("Android didn't allow a background recording service to start (${e.javaClass.simpleName}). Open MotoVox and try again.")
                    stopSelf(); return START_NOT_STICKY
                }
                if (watchJob?.isActive != true) scope.launch {
                    val s = app.settings.flow.first()
                    rec.start(RecConfig(project, s.sampleRate, s.channels, s.gainDb, s.splitMinutes, device, s.syncTone))
                    watch(project)
                }
            }
            ACTION_PAUSE -> rec.pause()
            ACTION_RESUME -> rec.resume()
            ACTION_STOP -> rec.stop()
            ACTION_MARK -> rec.addMarker()
        }
        if (!rec.isActive() && intent?.action != ACTION_START) stopSelf()
        return START_NOT_STICKY
    }

    private fun watch(project: String) {
        watchJob?.cancel()
        watchJob = scope.launch {
            app.recorder.ui.map { it.state to it.elapsedMs / 1000 }.distinctUntilChanged().collect { (st, sec) ->
                if (st == RecState.IDLE || st == RecState.ERROR) {
                    stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
                } else {
                    getSystemService(android.app.NotificationManager::class.java)
                        .notify(NOTIF_ID, buildNotification(st, sec * 1000, project))
                }
            }
        }
    }

    private fun enterForeground(n: Notification) {
        ServiceCompat.startForeground(this, NOTIF_ID, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
    }

    private fun buildNotification(state: RecState, elapsedMs: Long, project: String): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        fun act(a: String, code: Int) = PendingIntent.getService(this, code,
            Intent(this, RecordingService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
        val paused = state == RecState.PAUSED
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(if (paused) "MotoVox — paused" else "MotoVox — recording")
            .setContentText("$project • ${Naming.formatTime(elapsedMs)}")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        if (paused) b.addAction(0, "Resume", act(ACTION_RESUME, 2)) else b.addAction(0, "Pause", act(ACTION_PAUSE, 1))
        b.addAction(0, "Mark", act(ACTION_MARK, 3))
        b.addAction(0, "Stop", act(ACTION_STOP, 4))
        return b.build()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    companion object {
        const val CHANNEL_ID = "recording"
        const val NOTIF_ID = 1001
        const val ACTION_START = "com.motovox.app.START"
        const val ACTION_PAUSE = "com.motovox.app.PAUSE"
        const val ACTION_RESUME = "com.motovox.app.RESUME"
        const val ACTION_STOP = "com.motovox.app.STOP"
        const val ACTION_MARK = "com.motovox.app.MARK"
        const val EXTRA_PROJECT = "project"
        const val EXTRA_DEVICE = "device"
    }
}
