package com.motovox.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motovox.app.data.ThemeMode
import com.motovox.app.permissions.Perms

internal val TROUBLESHOOTING = listOf(
    "No signal from a wired mic: some USB-C and 3.5 mm adapters are output-only. Use an adapter that lists microphone/TRRS or USB-audio input support, then re-run the Mic test.",
    "3.5 mm headset mics need a TRRS (4-pole) plug. A 3-pole plug has no mic contact.",
    "Bluetooth: many earbuds and helmet intercoms only expose a low-bandwidth voice profile or no microphone to apps. Pair first, select it in Mic test, and check what route Android reports. If it falls back to the phone mic, MotoVox says so.",
    "Recording stops with the screen off: allow notifications, and in your phone's battery settings set MotoVox to unrestricted (names vary by manufacturer).",
    "Levels clip: lower the mic level or software gain, and move the mic away from your mouth/airflow. A windshield/foam cover helps far more than software.",
    "Wind noise: software can reduce low-frequency thump, but it can't remove wind that overlaps speech. Shelter the microphone physically.",
    "Syncing with the camera: clap, or enable the sync tone in Settings, at the start of both recordings and align the spikes in your video editor. Phone and camera clocks and start delays differ."
)

@Composable
fun SettingsScreen(vm: MainViewModel, onMicTest: () -> Unit) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val perms = remember(tick) { Perms.diagnostics(ctx) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    var prefix by remember(s.projectPrefix) { mutableStateOf(s.projectPrefix) }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        Text("Settings", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.headlineSmall)

        SectionCard("Recording") {
            Text("Format: WAV (16-bit PCM) while recording. Export a compact M4A (AAC) from the Library.", style = MaterialTheme.typography.bodySmall)
            Text("Sample rate / quality")
            ChipRow(listOf("48 kHz (default)" to 48000, "44.1 kHz" to 44100), s.sampleRate) { vm.setSampleRate(it) }
            Text("Channels")
            ChipRow(listOf("Mono (voice)" to 1, "Stereo" to 2), s.channels) { vm.setChannels(it) }
            Text("If an input can't capture the chosen rate or channels, MotoVox tells you when you start.", style = MaterialTheme.typography.bodySmall)
            LabeledSlider("Software gain", s.gainDb, -12f..24f, "%+.0f dB".format(s.gainDb), steps = 35) { vm.setGain(it) }
            Text("Software gain, not hardware gain: Android doesn't let apps change microphone hardware gain on every phone. Boosting also boosts noise and can clip.", style = MaterialTheme.typography.bodySmall)
            Text("Split long rides into files")
            ChipRow(listOf("Off" to 0, "15 min" to 15, "30 min" to 30, "60 min" to 60), s.splitMinutes) { vm.setSplit(it) }
            SwitchRow("Play sync tone at start", "Three short beeps on the phone speaker, picked up by phone and camera mics. Adds a 'Sync tone' marker.", s.syncTone) { vm.setSyncTone(it) }
            OutlinedTextField(prefix, { prefix = it.take(30) }, singleLine = true, label = { Text("Default project name prefix") }, modifier = Modifier.fillMaxWidth())
            if (prefix != s.projectPrefix) TextButton(onClick = { vm.setPrefix(prefix) }) { Text("Save prefix") }
        }

        SectionCard("Appearance") { ChipRow(listOf("Dark" to ThemeMode.DARK, "Light" to ThemeMode.LIGHT, "System" to ThemeMode.SYSTEM), s.theme) { vm.setTheme(it) } }

        SectionCard("Storage") {
            Text("Recordings are stored privately inside MotoVox: ${formatBytes(vm.usedBytes())} used, ${formatBytes(vm.freeBytes())} free on the phone.")
            Text("Delete recordings from the Library. Exports go wherever you choose in the system file picker. MotoVox never uploads anything. Uninstalling MotoVox deletes its private recordings, so export what you want to keep.", style = MaterialTheme.typography.bodySmall)
        }

        SectionCard("Permission diagnostics") {
            perms.forEach { p ->
                Row(Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("${p.label} — ${if (p.granted) "granted" else "not granted"}", fontWeight = FontWeight.SemiBold)
                        Text(p.purpose, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!p.granted) TextButton(onClick = { permL.launch(p.permission) }) { Text("Grant") }
                }
            }
            TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Open app settings") }
            TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Battery optimization settings") }
        }

        SectionCard("Troubleshooting") {
            TextButton(onClick = onMicTest) { Text("Open microphone test") }
            TROUBLESHOOTING.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }

        SectionCard("About MotoVox") {
            val v = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?" }
            Text("MotoVox $v — Ride. Record. Speak.")
            Text("An independent audio companion for action-camera video, not a camera replacement. Works fully offline: no account, no ads, no analytics, no internet permission. Recordings are never logged or uploaded.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
