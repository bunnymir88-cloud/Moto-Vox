package com.motovox.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "settings")

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class AppSettings(
    val sampleRate: Int = 48000,
    val channels: Int = 1,
    val gainDb: Float = 0f,
    val splitMinutes: Int = 0,
    val syncTone: Boolean = false,
    val projectPrefix: String = "Ride",
    val theme: ThemeMode = ThemeMode.DARK,
    val deviceId: Int = -1
)

class SettingsStore(private val ctx: Context) {
    private object K {
        val sr = intPreferencesKey("sr"); val ch = intPreferencesKey("ch")
        val gain = floatPreferencesKey("gain"); val split = intPreferencesKey("split")
        val tone = booleanPreferencesKey("tone"); val prefix = stringPreferencesKey("prefix")
        val theme = stringPreferencesKey("theme"); val dev = intPreferencesKey("dev")
    }

    val flow: Flow<AppSettings> = ctx.store.data.map { p: Preferences ->
        AppSettings(
            sampleRate = p[K.sr] ?: 48000, channels = p[K.ch] ?: 1, gainDb = p[K.gain] ?: 0f,
            splitMinutes = p[K.split] ?: 0, syncTone = p[K.tone] ?: false,
            projectPrefix = p[K.prefix] ?: "Ride",
            theme = runCatching { ThemeMode.valueOf(p[K.theme] ?: "DARK") }.getOrDefault(ThemeMode.DARK),
            deviceId = p[K.dev] ?: -1
        )
    }

    suspend fun setSampleRate(v: Int) = ctx.store.edit { it[K.sr] = v }
    suspend fun setChannels(v: Int) = ctx.store.edit { it[K.ch] = v }
    suspend fun setGain(v: Float) = ctx.store.edit { it[K.gain] = v }
    suspend fun setSplit(v: Int) = ctx.store.edit { it[K.split] = v }
    suspend fun setSyncTone(v: Boolean) = ctx.store.edit { it[K.tone] = v }
    suspend fun setPrefix(v: String) = ctx.store.edit { it[K.prefix] = v.take(30) }
    suspend fun setTheme(v: ThemeMode) = ctx.store.edit { it[K.theme] = v.name }
    suspend fun setDevice(v: Int) = ctx.store.edit { it[K.dev] = v }
}
