package com.motovox.app.recording

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioRecord
import android.os.Process
import com.motovox.app.audio.AudioCapture
import com.motovox.app.audio.AudioDevices
import com.motovox.app.audio.BluetoothRoute
import com.motovox.app.audio.Levels
import com.motovox.app.audio.WavIO
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/** Live meter + short recording (default 8 s) on the chosen input, for checking the route before a ride. Only reports measured values. */
class MicTest(private val ctx: Context) {
    data class State(
        val running: Boolean = false, val peak: Float = 0f, val maxPeakDb: Float = -120f, val clipped: Boolean = false,
        val route: String = "", val routeNote: String? = null, val sampleRate: Int = 0, val channels: Int = 0,
        val elapsedMs: Long = 0, val hasResult: Boolean = false, val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state = _state.asStateFlow()
    val file = File(ctx.cacheDir, "mictest.wav")
    @Volatile private var stopFlag = false

    fun stop() { stopFlag = true }

    fun start(deviceId: Int, sampleRate: Int, maxSeconds: Int = 8) {
        if (_state.value.running) return
        stopFlag = false
        _state.value = State(running = true)
        Thread({ run(deviceId, sampleRate, maxSeconds) }, "MotoVox-mictest").start()
    }

    private fun run(deviceId: Int, sampleRate: Int, maxSeconds: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val device: AudioDeviceInfo? = AudioDevices.find(ctx, deviceId)
        var bt = false
        if (device != null && AudioDevices.isBluetooth(device)) { bt = BluetoothRoute.activate(ctx, device); if (bt) Thread.sleep(800) }
        val opened = AudioCapture.open(ctx, sampleRate, 1, device)
        val ar: AudioRecord? = opened.record
        if (ar == null) {
            _state.update { it.copy(running = false, message = opened.error) }
            if (bt) BluetoothRoute.release(ctx); return
        }
        var maxPeak = 0; var clipped = false
        try {
            WavIO.Writer(file, ar.sampleRate, 1).use { w ->
                val buf = ShortArray(ar.sampleRate / 20)
                ar.startRecording()
                val total = ar.sampleRate.toLong() * maxSeconds; var frames = 0L
                while (!stopFlag && frames < total) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n < 0) { _state.update { it.copy(message = "The input stopped delivering audio (code $n).") }; break }
                    if (n == 0) continue
                    var p = 0
                    for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > p) p = a }
                    if (p >= Levels.CLIP_THRESHOLD) clipped = true
                    maxPeak = max(maxPeak, p)
                    w.write(buf, n); frames += n
                    val d = ar.routedDevice
                    val route = d?.let {
                        val k = AudioDevices.classify(it.type)
                        (it.productName?.toString()?.takeIf { s -> s.isNotBlank() } ?: AudioDevices.label(k, it.type)) + " — " + AudioDevices.label(k, it.type)
                    } ?: "unknown"
                    val note = if (d != null && device != null && d.id != device.id && d.type != device.type)
                        "The selected input isn't in use; Android chose a different one." else null
                    _state.update {
                        it.copy(peak = p / 32768f, maxPeakDb = Levels.peakToDb(maxPeak / 32768f), clipped = clipped,
                            route = route, routeNote = note, sampleRate = ar.sampleRate, channels = ar.channelCount,
                            elapsedMs = frames * 1000L / ar.sampleRate)
                    }
                }
            }
            _state.update { it.copy(running = false, peak = 0f, hasResult = file.length() > 44) }
        } catch (e: Exception) {
            _state.update { it.copy(running = false, message = "Test failed: ${e.message}") }
        } finally {
            runCatching { ar.stop() }; ar.release()
            if (bt) BluetoothRoute.release(ctx)
        }
    }

    /** Plain-language reading of the measured peak. */
    fun verdict(s: State): String = when {
        s.maxPeakDb <= -90f -> "No signal was captured. Check the cable/adapter (some adapters are output-only) or the selected input."
        s.clipped -> "Clipping detected. Lower the microphone level or move it away from your mouth."
        s.maxPeakDb < -30f -> "Signal is very quiet (peak %.0f dBFS). Speak closer or raise the microphone/software gain.".format(s.maxPeakDb)
        s.maxPeakDb < -18f -> "Usable but a little quiet (peak %.0f dBFS).".format(s.maxPeakDb)
        else -> "Good level (peak %.0f dBFS).".format(s.maxPeakDb)
    }
}
