package com.motovox.app.data

import android.content.Context
import com.motovox.app.audio.WavIO
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import java.io.File
import java.util.UUID

/** Metadata index (index.json) plus audio files, all in app-private storage (no storage permission needed). */
class RecordingRepository(ctx: Context) {
    val dir = File(ctx.filesDir, "recordings").apply { mkdirs() }
    private val index = File(ctx.filesDir, "index.json")
    private val lock = Any()
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<RecordingMeta>> = _items.asStateFlow()

    private fun load(): List<RecordingMeta> = try {
        if (!index.exists()) emptyList() else {
            val arr = JSONArray(index.readText())
            (0 until arr.length()).map { RecordingMeta.fromJson(arr.getJSONObject(it)) }
        }
    } catch (e: Exception) { emptyList() }

    private fun persist(list: List<RecordingMeta>) {
        val tmp = File(index.parentFile, "index.json.tmp")
        val arr = JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(index)) { index.delete(); tmp.renameTo(index) }
        _items.value = list
    }

    fun newId(): String = UUID.randomUUID().toString()
    fun fileOf(m: RecordingMeta) = File(dir, m.fileName)
    fun get(id: String) = _items.value.firstOrNull { it.id == id }

    fun upsert(m: RecordingMeta) = synchronized(lock) {
        val cur = _items.value
        persist(if (cur.any { it.id == m.id }) cur.map { if (it.id == m.id) m else it } else cur + m)
    }

    fun update(id: String, f: (RecordingMeta) -> RecordingMeta) = synchronized(lock) {
        persist(_items.value.map { if (it.id == id) f(it) else it })
    }

    fun delete(id: String) = synchronized(lock) {
        val m = _items.value.firstOrNull { it.id == id } ?: return@synchronized
        fileOf(m).delete()
        persist(_items.value.filter { it.id != id })
    }

    fun usedBytes(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    /** Repairs WAVs left half-written by a crash/kill and indexes unknown WAV files. Call only while not recording. */
    fun recoverInterrupted() = synchronized(lock) {
        dir.listFiles { f -> f.extension == "part" }?.forEach { it.delete() }
        var changed = false
        val fixed = _items.value.map { m ->
            if (m.status != RecStatus.RECORDING) m else {
                changed = true
                val f = fileOf(m)
                val ok = f.exists() && WavIO.repairHeader(f)
                val info = if (ok) WavIO.readInfo(f) else null
                m.copy(status = RecStatus.RECOVERED, durationMs = info?.durationMs ?: m.durationMs, sizeBytes = f.length())
            }
        }.toMutableList()
        val known = fixed.map { it.fileName }.toSet()
        dir.listFiles { f -> f.extension == "wav" && f.name !in known }?.forEach { f ->
            if (WavIO.repairHeader(f)) WavIO.readInfo(f)?.let { info ->
                changed = true
                fixed += RecordingMeta(newId(), f.nameWithoutExtension, f.name, RecordingKind.VOICE,
                    f.lastModified(), info.durationMs, info.sampleRate, info.channels, f.length(), RecStatus.RECOVERED)
            }
        }
        if (changed) persist(fixed)
    }
}
