package com.motovox.app.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.DocumentsContract
import com.motovox.app.audio.WavIO
import com.motovox.app.data.Naming
import com.motovox.app.data.RecordingMeta
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.nio.ByteOrder

object Exporter {
    fun markersCsv(m: RecordingMeta): String = buildString {
        append("index,time_ms,time,label\n")
        m.markers.sortedBy { it.timeMs }.forEachIndexed { i, mk ->
            append("${i + 1},${mk.timeMs},${Naming.formatTime(mk.timeMs, true)},\"${mk.label.replace("\"", "\"\"")}\"\n")
        }
    }

    fun markersJson(m: RecordingMeta): String = JSONObject().apply {
        put("project", m.name); put("startedAtEpochMs", m.createdAt); put("durationMs", m.durationMs)
        put("note", "Times are relative to the start of this audio file. Phone and camera clocks and start delays differ; align by ear/waveform.")
        put("markers", JSONArray().also { a -> m.markers.sortedBy { it.timeMs }.forEach { a.put(JSONObject().put("timeMs", it.timeMs).put("label", it.label)) } })
    }.toString(2)

    fun metadataJson(m: RecordingMeta): String = m.toJson().apply { remove("fileName") }.toString(2)

    fun writeText(ctx: Context, uri: Uri, text: String): String? = try {
        ctx.contentResolver.openOutputStream(uri, "w")?.use { it.write(text.toByteArray()) } ?: throw IOException("Can't open destination")
        null
    } catch (e: Exception) { discard(ctx, uri); "Export failed: ${e.message}" }

    fun copyFile(ctx: Context, src: File, uri: Uri, onProgress: (Float) -> Unit, cancelled: () -> Boolean): String? = try {
        val total = src.length().coerceAtLeast(1)
        ctx.contentResolver.openOutputStream(uri, "w")?.use { out ->
            src.inputStream().use { input ->
                val buf = ByteArray(64 * 1024); var done = 0L
                while (true) {
                    if (cancelled()) throw IOException("Cancelled")
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n; onProgress(done.toFloat() / total)
                }
            }
        } ?: throw IOException("Can't open destination")
        null
    } catch (e: Exception) { discard(ctx, uri); if (e.message == "Cancelled") "Cancelled" else "Export failed: ${e.message}" }

    fun exportM4a(ctx: Context, src: File, uri: Uri, onProgress: (Float) -> Unit, cancelled: () -> Boolean): String? {
        val tmp = File(ctx.cacheDir, "export_${System.nanoTime()}.m4a")
        try {
            val err = wavToM4a(src, tmp, { onProgress(it * 0.85f) }, cancelled)
            if (err != null) { discard(ctx, uri); return err }
            return copyFile(ctx, tmp, uri, { onProgress(0.85f + it * 0.15f) }, cancelled)
        } finally { tmp.delete() }
    }

    private fun discard(ctx: Context, uri: Uri) { runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, uri) } }

    /** AAC-LC in an MP4 (.m4a) container using the platform encoder. Returns an error message or null. */
    fun wavToM4a(src: File, dst: File, onProgress: (Float) -> Unit, cancelled: () -> Boolean): String? {
        val rd = try { WavIO.Reader(src) } catch (e: IOException) { return e.message }
        var codec: MediaCodec? = null; var muxer: MediaMuxer? = null
        try {
            rd.use {
                val sr = rd.info.sampleRate; val ch = rd.info.channels
                val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, ch).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, if (ch == 1) 96_000 else 160_000)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32 * 1024)
                }
                codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).also {
                    it.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); it.start()
                }
                muxer = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                var track = -1; var started = false
                val info = MediaCodec.BufferInfo()
                var inDone = false; var frames = 0L
                val total = rd.info.frames.coerceAtLeast(1)
                val c = codec!!
                while (true) {
                    if (cancelled()) return "Cancelled"
                    if (!inDone) {
                        val ii = c.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val ib = c.getInputBuffer(ii)!!; ib.clear()
                            val tmp = ShortArray((ib.capacity() / 2 / ch) * ch)
                            val n = rd.read(tmp)
                            val pts = frames * 1_000_000L / sr
                            if (n <= 0) { c.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                            else {
                                ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(tmp, 0, n)
                                c.queueInputBuffer(ii, 0, n * 2, pts, 0); frames += n / ch
                                onProgress((frames.toFloat() / total).coerceAtMost(1f))
                            }
                        }
                    }
                    val oi = c.dequeueOutputBuffer(info, 10_000)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = muxer!!.addTrack(c.outputFormat); muxer!!.start(); started = true
                    } else if (oi >= 0) {
                        val ob = c.getOutputBuffer(oi)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && started) {
                            ob.position(info.offset); ob.limit(info.offset + info.size)
                            muxer!!.writeSampleData(track, ob, info)
                        }
                        c.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
            return null
        } catch (e: Exception) {
            return "AAC encoding failed: ${e.message ?: "encoder error"}"
        } finally {
            runCatching { codec?.stop() }; runCatching { codec?.release() }
            runCatching { muxer?.stop() }; runCatching { muxer?.release() }
        }
    }
}
