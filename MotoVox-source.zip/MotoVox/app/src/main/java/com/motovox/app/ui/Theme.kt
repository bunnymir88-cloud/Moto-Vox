package com.motovox.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.motovox.app.data.ThemeMode

object MV {
    val Black = Color(0xFF080B10); val Charcoal = Color(0xFF111820); val Raised = Color(0xFF1A232E)
    val Red = Color(0xFFFF3048); val Green = Color(0xFF39E58C); val White = Color(0xFFF5F7FA)
    val Grey = Color(0xFF8A96A6); val Amber = Color(0xFFFFB020)
}

private val DarkScheme = darkColorScheme(
    primary = MV.Red, onPrimary = MV.White, secondary = MV.Green, onSecondary = MV.Black,
    background = MV.Black, onBackground = MV.White, surface = MV.Charcoal, onSurface = MV.White,
    surfaceVariant = MV.Raised, onSurfaceVariant = MV.Grey, error = MV.Red, outline = Color(0xFF2E3A48)
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFFD81B3A), onPrimary = Color.White, secondary = Color(0xFF0B7A49), onSecondary = Color.White,
    background = MV.White, onBackground = MV.Charcoal, surface = Color.White, onSurface = MV.Charcoal,
    surfaceVariant = Color(0xFFE6EBF1), onSurfaceVariant = Color(0xFF4A5666), error = Color(0xFFB3001B)
)

@Composable
fun MotoVoxTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
