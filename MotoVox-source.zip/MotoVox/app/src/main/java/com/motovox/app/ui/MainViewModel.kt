package com.motovox.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.motovox.app.MotoVoxApp
import com.motovox.app.audio.AudioDevices
import com.motovox.app.audio.InputDevice
import com.motovox.app.audio.WavIO
import com.motovox.app.data.*
import com.motovox.app.effects.*
import com.motovox.app.export.Exporter
import com.motovox.app.mixer.*
import com.motovox.app.recording.MicTest
import com.motovox.app.recording.RecordingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

data class JobState(val running: Boolean = false, val title: String = "", val progress: Float = 0f,
                    val message: String? = null, val isError: Boolean = false)
data class JobResult(val ok: Boolean, val message: String)
data class FxUi(val sourceId: String? = null, val fx: FxParams = FxParams(), val enhance: EnhanceParams = EnhanceParams())
data class MixUi(val voiceId: String? = null, val musicUri: Uri? = null, val musicName: String = "",
                 val musicDurationMs: Long = 0, val params: MixParams = MixParams(), val preset: String = "")
enum class ExportKind { WAV, M4A, MARKERS_CSV, MARKERS_JSON, METADATA }

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as MotoVoxApp
    private val repo = app.repo
    private val audioManager = application.getSystemService(AudioManager::class.java)

    val settings: StateFlow<AppSettings> = app.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val recordings: StateFlow<List<RecordingMeta>> = repo.items
    val rec = app.recorder.ui
    val micTest = MicTest(application)

    val fxUi = MutableStateFlow(FxUi())
    val mixUi = MutableStateFlow(MixUi())
    val job = MutableStateFlow(JobState())
    val notice = MutableStateFlow<String?>(null)
    val playingKey = MutableStateFlow<String?>(null)

    private val _inputs = MutableStateFlow(AudioDevices.list(application))
    val inputs: StateFlow<List<InputDevice>> = _inputs.asStateFlow()
    private val deviceCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { _inputs.value = AudioDevices.list(application) }
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { _inputs.value = AudioDevices.list(application) }
    }
    init { audioManager.registerAudioDeviceCallback(deviceCb, Handler(Looper.getMainLooper())) }

    override fun onCleared() {
        audioManager.unregisterAudioDeviceCallback(deviceCb); stopPlayback(); micTest.stop()
    }

    // ---------- settings ----------
    private fun set(f: suspend () -> Unit) { viewModelScope.launch { f() } }
    fun setSampleRate(v: Int) = set { app.settings.setSampleRate(v) }
    fun setChannels(v: Int) = set { app.settings.setChannels(v) }
    fun setGain(v: Float) = set { app.settings.setGain(v) }
    fun setSplit(v: Int) = set { app.settings.setSplit(v) }
    fun setSyncTone(v: Boolean) = set { app.settings.setSyncTone(v) }
    fun setPrefix(v: String) = set { app.settings.setPrefix(v) }
    fun setTheme(v: ThemeMode) = set { app.settings.setTheme(v) }
    fun setDevice(v: Int) = set { app.settings.setDevice(v) }

    // ---------- recording ----------
    fun startRecording(ctx: Context, project: String) {
        val name = project.ifBlank { Naming.defaultProject(settings.value.projectPrefix, System.currentTimeMillis()) }
        ContextCompat.startForegroundService(ctx, Intent(ctx, RecordingService::class.java)
            .setAction(RecordingService.ACTION_START)
            .putExtra(RecordingService.EXTRA_PROJECT, name)
            .putExtra(RecordingService.EXTRA_DEVICE, settings.value.deviceId))
    }
    fun pauseRecording() = app.recorder.pause()
    fun resumeRecording() = app.recorder.resume()
    fun stopRecording() = app.recorder.stop()
    fun addMarker() = app.recorder.addMarker()
    fun dismissRecError() = app.recorder.dismissError()
    fun freeBytes(): Long = repo.dir.usableSpace
    fun usedBytes(): Long = repo.usedBytes()

    // ---------- library ----------
    fun fileOf(m: RecordingMeta) = repo.fileOf(m)
    fun rename(id: String, name: String) = repo.update(id) { it.copy(name = name.trim().ifEmpty { it.name }) }
    fun toggleFavorite(id: String) = repo.update(id) { it.copy(favorite = !it.favorite) }
    fun setNotes(id: String, notes: String) = repo.update(id) { it.copy(notes = notes) }
    fun delete(id: String) { if (playingKey.value == id) stopPlayback(); repo.delete(id) }
    fun duplicate(id: String) {
        val m = repo.get(id) ?: return
        val src = repo.fileOf(m)
        if (!src.exists()) { notice.value = "Can't duplicate: the audio file is missing."; return }
        viewModelScope.launch(Dispatchers.IO) {
            val newName = Naming.fileName(m.name, System.currentTimeMillis(), "copy")
            runCatching { src.copyTo(File(repo.dir, newName), overwrite = false) }
                .onSuccess { repo.upsert(m.copy(id = repo.newId(), name = m.name + " (copy)", fileName = newName,
                    createdAt = System.currentTimeMillis(), favorite = false, parentId = m.id)) }
                .onFailure { notice.value = "Couldn't duplicate (${it.message}). Check free storage." }
        }
    }

    // ---------- playback ----------
    private var mp: MediaPlayer? = null
    fun togglePlay(key: String, file: File) {
        if (playingKey.value == key) { stopPlayback(); return }
        stopPlayback()
        if (!file.exists()) { notice.value = "That audio file is missing. It may have been moved or deleted."; return }
        try {
            mp = MediaPlayer().apply {
                setDataSource(file.path)
                setOnCompletionListener { stopPlayback() }
                setOnErrorListener { _, _, _ -> stopPlayback(); true }
                prepare(); start()
            }
            playingKey.value = key
        } catch (e: Exception) { stopPlayback(); notice.value = "Can't play this file: ${e.message ?: "unsupported audio"}" }
    }
    fun stopPlayback() { runCatching { mp?.release() }; mp = null; playingKey.value = null }

    // ---------- jobs ----------
    private val cancelFlag = AtomicBoolean(false)
    fun cancelJob() = cancelFlag.set(true)
    fun dismissJob() { if (!job.value.running) job.value = JobState() }

    private fun runJob(title: String, then: () -> Unit = {}, block: (progress: (Float) -> Unit, cancelled: () -> Boolean) -> JobResult) {
        if (job.value.running) return
        cancelFlag.set(false)
        job.value = JobState(running = true, title = title)
        viewModelScope.launch(Dispatchers.IO) {
            val r = try { block({ p -> job.update { it.copy(progress = p) } }, { cancelFlag.get() }) }
            catch (e: Exception) { JobResult(false, "$title failed: ${e.message ?: "unexpected error"}") }
            job.value = JobState(false, title, 1f, r.message, !r.ok)
            if (r.ok) withContext(Dispatchers.Main) { then() }
        }
    }

    // ---------- Voice FX ----------
    private fun fxSource(): RecordingMeta? = recordings.value.firstOrNull { it.id == fxUi.value.sourceId }

    fun previewOriginal() { fxSource()?.let { togglePlay("fx-orig", repo.fileOf(it)) } }

    fun previewProcessed() {
        val src = fxSource() ?: return; val ui = fxUi.value
        stopPlayback()
        val out = File(app.cacheDir, "preview_fx.wav")
        runJob("Rendering preview", then = { togglePlay("fx-proc", out) }) { prog, cancelled ->
            WavIO.validate(repo.fileOf(src))?.let { return@runJob JobResult(false, it) }
            val r = OfflineProcessor.run(repo.fileOf(src), out, ChainBuilder.build(src.sampleRate, ui.enhance, ui.fx),
                ChainBuilder.tailSeconds(ui.fx), 12f, prog, cancelled)
            if (r.ok) JobResult(true, "Preview ready (first 12 seconds).") else JobResult(false, r.error ?: "Preview failed.")
        }
    }

    fun applyFx() {
        val src = fxSource() ?: return; val ui = fxUi.value
        runJob("Processing") { prog, cancelled ->
            val srcFile = repo.fileOf(src)
            WavIO.validate(srcFile)?.let { return@runJob JobResult(false, it) }
            val label = if (ui.fx.effect == VoiceEffect.ORIGINAL) "Enhanced" else ui.fx.effect.label
            val fileName = Naming.fileName(src.name, System.currentTimeMillis(), label)
            val finalFile = File(repo.dir, fileName); val part = File(repo.dir, "$fileName.part")
            val r = OfflineProcessor.run(srcFile, part, ChainBuilder.build(src.sampleRate, ui.enhance, ui.fx),
                ChainBuilder.tailSeconds(ui.fx), 0f, prog, cancelled)
            if (!r.ok) { part.delete(); return@runJob JobResult(false, if (r.error == "Cancelled") "Cancelled. Your original recording is untouched." else r.error ?: "Processing failed.") }
            part.renameTo(finalFile)
            val info = WavIO.readInfo(finalFile)
            val name = "${src.name} — $label"
            repo.upsert(RecordingMeta(repo.newId(), name, fileName, RecordingKind.PROCESSED, System.currentTimeMillis(),
                info?.durationMs ?: 0, src.sampleRate, 1, finalFile.length(), RecStatus.COMPLETE, markers = src.markers, parentId = src.id))
            JobResult(true, "Saved “$name” to your Library. The original is unchanged.")
        }
    }

    // ---------- Music & Mix ----------
    fun pickMusic(uri: Uri) {
        runJob("Checking music file") { _, _ ->
            val (probe, err) = MusicDecoder.probe(app, uri)
            if (probe == null) JobResult(false, err ?: "Unsupported file.")
            else {
                mixUi.update { it.copy(musicUri = uri, musicName = probe.name, musicDurationMs = probe.durationMs,
                    params = it.params.copy(trimStartMs = 0, trimEndMs = 0)) }
                JobResult(true, "Loaded “${probe.name}”.")
            }
        }
    }

    private fun musicCache(uri: Uri, sr: Int) = File(app.cacheDir, "music_${uri.toString().hashCode().toLong() and 0xffffffffL}_$sr.wav")

    fun runMix(preview: Boolean) {
        val m = mixUi.value
        val src = recordings.value.firstOrNull { it.id == m.voiceId } ?: return
        val uri = m.musicUri ?: run { notice.value = "Choose a music file first."; return }
        stopPlayback()
        val prevFile = File(app.cacheDir, "preview_mix.wav")
        runJob(if (preview) "Rendering mix preview" else "Mixing", then = { if (preview) togglePlay("mix-prev", prevFile) }) { prog, cancelled ->
            val srcFile = repo.fileOf(src)
            WavIO.validate(srcFile)?.let { return@runJob JobResult(false, it) }
            val cache = musicCache(uri, src.sampleRate)
            if (WavIO.readInfo(cache) == null) {
                val part = File(cache.path + ".part")
                val err = MusicDecoder.decode(app, uri, part, src.sampleRate, { prog(it * 0.5f) }, cancelled)
                if (err != null) { part.delete(); return@runJob JobResult(false, err) }
                part.renameTo(cache)
            }
            val fileName = Naming.fileName(src.name, System.currentTimeMillis(), "mix")
            val out = if (preview) prevFile else File(repo.dir, "$fileName.part")
            val r = Mixer.mix(srcFile, cache, out, m.params, if (preview) 20f else 0f, { prog(0.5f + it * 0.5f) }, cancelled)
            if (!r.ok) { out.delete(); return@runJob JobResult(false, if (r.error == "Cancelled") "Cancelled." else r.error ?: "Mix failed.") }
            if (preview) return@runJob JobResult(true, "Preview ready (first 20 seconds).")
            val finalFile = File(repo.dir, fileName); out.renameTo(finalFile)
            val info = WavIO.readInfo(finalFile)
            val name = "${src.name} — Mix"
            repo.upsert(RecordingMeta(repo.newId(), name, fileName, RecordingKind.MIX, System.currentTimeMillis(),
                info?.durationMs ?: 0, src.sampleRate, 1, finalFile.length(), RecStatus.COMPLETE, markers = src.markers, parentId = src.id))
            JobResult(true, "Saved “$name” to your Library. Voice and music sources are unchanged.")
        }
    }

    // ---------- Export ----------
    private fun queryNameSize(uri: Uri): Pair<String?, Long?> = try {
        getApplication<Application>().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) to (if (it.isNull(1)) null else it.getLong(1)) else null to null
        } ?: (null to null)
    } catch (e: Exception) { null to null }

    fun export(kind: ExportKind, id: String, uri: Uri) {
        val m = repo.get(id) ?: return
        val ctx = getApplication<Application>()
        runJob("Exporting") { prog, cancelled ->
            val src = repo.fileOf(m)
            if (kind == ExportKind.WAV || kind == ExportKind.M4A) {
                WavIO.validate(src)?.let { return@runJob JobResult(false, it) }
            }
            val err = when (kind) {
                ExportKind.WAV -> Exporter.copyFile(ctx, src, uri, prog, cancelled)
                ExportKind.M4A -> Exporter.exportM4a(ctx, src, uri, prog, cancelled)
                ExportKind.MARKERS_CSV -> Exporter.writeText(ctx, uri, Exporter.markersCsv(m))
                ExportKind.MARKERS_JSON -> Exporter.writeText(ctx, uri, Exporter.markersJson(m))
                ExportKind.METADATA -> Exporter.writeText(ctx, uri, Exporter.metadataJson(m))
            }
            if (err != null) return@runJob JobResult(false, if (err == "Cancelled") "Export cancelled. No file was kept." else err)
            val (name, size) = queryNameSize(uri)
            val fmt = when (kind) { ExportKind.WAV -> "WAV (16-bit PCM)"; ExportKind.M4A -> "M4A (AAC-LC)"; ExportKind.MARKERS_CSV -> "CSV"; else -> "JSON" }
            val audio = kind == ExportKind.WAV || kind == ExportKind.M4A
            JobResult(true, "Exported ${name ?: "file"} — $fmt" + (if (audio) ", ${Naming.formatTime(m.durationMs)}" else "") +
                (size?.let { ", ${formatBytes(it)}" } ?: "") + ". Saved to the location you chose.")
        }
    }
}
