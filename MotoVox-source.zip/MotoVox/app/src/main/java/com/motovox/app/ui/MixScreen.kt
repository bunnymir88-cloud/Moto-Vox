package com.motovox.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motovox.app.data.Naming
import com.motovox.app.data.RecStatus
import com.motovox.app.data.RecordingKind
import com.motovox.app.mixer.MixParams
import com.motovox.app.mixer.MixPresets
import kotlinx.coroutines.flow.update

@Composable
fun MixScreen(vm: MainViewModel) {
    val ui by vm.mixUi.collectAsStateWithLifecycle()
    val recs by vm.recordings.collectAsStateWithLifecycle()
    val playing by vm.playingKey.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    val usable = recs.filter { it.kind != RecordingKind.MIX && it.status != RecStatus.RECORDING }.sortedByDescending { it.createdAt }
    val voice = usable.firstOrNull { it.id == ui.voiceId }
    var menu by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.pickMusic(uri) }
    LaunchedEffect(usable.size) { if (voice == null) vm.mixUi.update { it.copy(voiceId = usable.firstOrNull()?.id) } }
    val p = ui.params
    fun upd(f: (MixParams) -> MixParams) = vm.mixUi.update { it.copy(params = f(it.params), preset = "") }
    val musicSec = (ui.musicDurationMs / 1000f).let { if (it < 1f) 600f else it }
    val ready = voice != null && ui.musicUri != null && !job.running

    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        Text("Music & Mix", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.headlineSmall)

        SectionCard("1 · Voice") {
            if (usable.isEmpty()) Text("Record something first.")
            else Box {
                OutlinedButton(onClick = { menu = true }, Modifier.fillMaxWidth()) {
                    Text(voice?.let { "${it.name} • ${Naming.formatTime(it.durationMs)}" } ?: "Choose recording", Modifier.weight(1f), maxLines = 1)
                    Icon(Icons.Filled.KeyboardArrowDown, null)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    usable.forEach { m -> DropdownMenuItem(text = { Text(m.name) }, onClick = { vm.mixUi.update { it.copy(voiceId = m.id) }; menu = false }) }
                }
            }
        }

        SectionCard("2 · Music from your phone") {
            Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !job.running) {
                Text(if (ui.musicUri == null) "Choose music file" else "Change music file") }
            if (ui.musicUri != null) Text("${ui.musicName}" + if (ui.musicDurationMs > 0) " • ${Naming.formatTime(ui.musicDurationMs)}" else "")
            Text("MP3, AAC, WAV and other formats your phone can decode. Only music you have the rights to use. The file isn't copied or modified; it is decoded temporarily while mixing.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("3 · Preset") {
            ChipRow(MixPresets.all.map { it.name to it.name }, ui.preset) { name ->
                val pr = MixPresets.all.first { it.name == name }
                vm.mixUi.update { cur ->
                    cur.copy(preset = name, params = pr.params.copy(trimStartMs = cur.params.trimStartMs, trimEndMs = cur.params.trimEndMs, musicOffsetMs = cur.params.musicOffsetMs))
                }
            }
            Text("Presets set the sliders below (levels, fades, ducking). Adjust anything afterwards.", style = MaterialTheme.typography.bodySmall)
        }

        SectionCard("4 · Levels & timing") {
            LabeledSlider("Voice volume", p.voiceGainDb, -12f..12f, "%+.1f dB".format(p.voiceGainDb)) { v -> upd { it.copy(voiceGainDb = v) } }
            LabeledSlider("Music volume", p.musicGainDb, -40f..0f, "%.1f dB".format(p.musicGainDb)) { v -> upd { it.copy(musicGainDb = v) } }
            LabeledSlider("Lower music under speech", p.duckDb, -20f..0f, if (p.duckDb == 0f) "Off" else "%.0f dB".format(p.duckDb)) { v -> upd { it.copy(duckDb = v) } }
            LabeledSlider("Music starts at", p.musicOffsetMs / 1000f, 0f..60f, "%.1f s".format(p.musicOffsetMs / 1000f)) { v -> upd { it.copy(musicOffsetMs = (v * 1000).toLong()) } }
            LabeledSlider("Trim music start", p.trimStartMs / 1000f, 0f..musicSec, "%.1f s".format(p.trimStartMs / 1000f)) { v -> upd { it.copy(trimStartMs = (v * 1000).toLong()) } }
            LabeledSlider("Trim music end (0 = full)", p.trimEndMs / 1000f, 0f..musicSec, if (p.trimEndMs == 0L) "Full" else "%.1f s".format(p.trimEndMs / 1000f)) { v -> upd { it.copy(trimEndMs = (v * 1000).toLong()) } }
            LabeledSlider("Fade in", p.fadeInMs / 1000f, 0f..10f, "%.1f s".format(p.fadeInMs / 1000f)) { v -> upd { it.copy(fadeInMs = (v * 1000).toLong()) } }
            LabeledSlider("Fade out", p.fadeOutMs / 1000f, 0f..10f, "%.1f s".format(p.fadeOutMs / 1000f)) { v -> upd { it.copy(fadeOutMs = (v * 1000).toLong()) } }
            SwitchRow("Loop music", "Repeats the trimmed section until the voice ends", p.loop) { v -> upd { it.copy(loop = v) } }
            SwitchRow("Output limiter", "Prevents clipping in the final mix", p.limiter) { v -> upd { it.copy(limiter = v) } }
        }

        SectionCard("5 · Preview & save") {
            OutlinedButton(onClick = { if (playing == "mix-prev") vm.stopPlayback() else vm.runMix(true) }, enabled = ready || playing == "mix-prev", modifier = Modifier.fillMaxWidth()) {
                Text(if (playing == "mix-prev") "Stop preview" else "Preview first 20 seconds") }
            Button(onClick = { vm.runMix(false) }, enabled = ready, modifier = Modifier.fillMaxWidth()) { Text("Save mix to Library") }
            Text("The mix is as long as your voice recording and saved as a new mono WAV. Your voice recording and music file are untouched. Export from the Library.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
