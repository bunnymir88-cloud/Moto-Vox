package com.motovox.app.audio

import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Minimal streaming reader/writer for 16-bit PCM WAV. Never loads a whole file into memory. */
object WavIO {
    const val HEADER_BYTES = 44

    data class WavInfo(val sampleRate: Int, val channels: Int, val dataOffset: Long, val dataBytes: Long) {
        val frames: Long get() = dataBytes / (channels * 2L)
        val durationMs: Long get() = if (sampleRate == 0) 0 else frames * 1000L / sampleRate
    }

    fun writeHeader(raf: RandomAccessFile, sampleRate: Int, channels: Int, dataBytes: Long) {
        val b = ByteBuffer.allocate(HEADER_BYTES).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataBytes).coerceAtMost(0xFFFFFFFFL).toInt())
        b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray()); b.putInt(16)
        b.putShort(1); b.putShort(channels.toShort()); b.putInt(sampleRate)
        b.putInt(sampleRate * channels * 2); b.putShort((channels * 2).toShort()); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataBytes.coerceAtMost(0xFFFFFFFFL).toInt())
        raf.seek(0); raf.write(b.array())
    }

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    /** Returns null unless the file is 16-bit PCM WAV. Tolerates sizes left wrong by an interrupted recording. */
    fun readInfo(file: File): WavInfo? {
        if (!file.isFile || file.length() < HEADER_BYTES) return null
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val hdr = ByteArray(12); raf.readFully(hdr)
                if (String(hdr, 0, 4, Charsets.US_ASCII) != "RIFF" || String(hdr, 8, 4, Charsets.US_ASCII) != "WAVE") return null
                var sr = 0; var ch = 0; var bits = 0; var tag = 0
                while (raf.filePointer + 8 <= raf.length()) {
                    val h = ByteArray(8); raf.readFully(h)
                    val id = String(h, 0, 4, Charsets.US_ASCII); val size = le32(h, 4)
                    val start = raf.filePointer
                    when (id) {
                        "fmt " -> {
                            if (size < 16) return null
                            val b = ByteArray(minOf(size, 40L).toInt()); raf.readFully(b)
                            tag = le16(b, 0); ch = le16(b, 2); sr = le32(b, 4).toInt(); bits = le16(b, 14)
                            raf.seek(start + size + (size and 1L))
                        }
                        "data" -> {
                            if (sr <= 0 || ch !in 1..2 || bits != 16 || (tag != 1 && tag != 0xFFFE)) return null
                            val remaining = file.length() - start
                            val bytes = if (size == 0L || size > remaining) remaining else size
                            return WavInfo(sr, ch, start, bytes - bytes % (ch * 2L))
                        }
                        else -> raf.seek(start + size + (size and 1L))
                    }
                }
                null
            }
        } catch (e: IOException) { null }
    }

    /** Human-readable reason a file can't be used, or null if it is a supported WAV. */
    fun validate(file: File): String? = when {
        !file.exists() -> "The file is missing."
        readInfo(file) == null -> "Unsupported or damaged file (MotoVox reads 16-bit PCM WAV)."
        else -> null
    }

    /** Rewrites header sizes from the real file length. Only for 44-byte-header files written by MotoVox. */
    fun repairHeader(file: File): Boolean {
        val info = readInfo(file) ?: return false
        if (info.dataOffset != HEADER_BYTES.toLong()) return false
        return try {
            RandomAccessFile(file, "rw").use {
                writeHeader(it, info.sampleRate, info.channels, info.dataBytes)
                it.setLength(HEADER_BYTES + info.dataBytes)
            }
            true
        } catch (e: IOException) { false }
    }

    class Writer(val file: File, val sampleRate: Int, val channels: Int) : Closeable {
        private val raf = RandomAccessFile(file, "rw")
        private var bytes = 0L
        private var scratch = ByteArray(0)
        init { raf.setLength(0); writeHeader(raf, sampleRate, channels, 0) }
        val dataBytes: Long get() = bytes
        val frames: Long get() = bytes / (channels * 2L)

        fun write(s: ShortArray, n: Int) {
            if (scratch.size < n * 2) scratch = ByteArray(n * 2)
            var j = 0
            for (i in 0 until n) { val v = s[i].toInt(); scratch[j++] = v.toByte(); scratch[j++] = (v shr 8).toByte() }
            raf.write(scratch, 0, n * 2); bytes += n * 2L
        }

        /** Keeps the on-disk header valid so a crash loses at most the last few seconds. */
        fun flushHeader() { val pos = raf.filePointer; writeHeader(raf, sampleRate, channels, bytes); raf.seek(pos) }

        override fun close() {
            try { flushHeader(); runCatching { raf.fd.sync() } } finally { raf.close() }
        }
    }

    class Reader(file: File) : Closeable {
        val info: WavInfo = readInfo(file) ?: throw IOException("Not a supported 16-bit PCM WAV file")
        private val raf = RandomAccessFile(file, "r")
        private var remaining = info.dataBytes
        private var scratch = ByteArray(0)
        init { raf.seek(info.dataOffset) }

        fun seekFrame(frame: Long) {
            val b = (frame * info.channels * 2L).coerceIn(0L, info.dataBytes)
            raf.seek(info.dataOffset + b); remaining = info.dataBytes - b
        }

        /** Reads up to maxSamples interleaved samples (whole frames). Returns samples read, 0 at end. */
        fun read(out: ShortArray, maxSamples: Int = out.size): Int {
            var want = minOf(maxSamples.toLong(), remaining / 2, out.size.toLong()).toInt()
            want -= want % info.channels
            if (want <= 0) return 0
            if (scratch.size < want * 2) scratch = ByteArray(want * 2)
            raf.readFully(scratch, 0, want * 2)
            for (i in 0 until want) out[i] = ((scratch[2 * i].toInt() and 0xFF) or (scratch[2 * i + 1].toInt() shl 8)).toShort()
            remaining -= want * 2L
            return want
        }

        override fun close() = raf.close()
    }
}
