package com.motovox.app.recording

import com.motovox.app.data.Marker

enum class RecState { IDLE, PREPARING, RECORDING, PAUSED, STOPPING, ERROR }
enum class RecEvent { START, STARTED, PAUSE, RESUME, STOP, STOPPED, FAIL, RESET }

/** Pure transition table. Returns null for an invalid transition (the event is ignored). */
object RecStateMachine {
    fun next(s: RecState, e: RecEvent): RecState? = when (s) {
        RecState.IDLE -> when (e) { RecEvent.START -> RecState.PREPARING; RecEvent.FAIL -> RecState.ERROR; else -> null }
        RecState.PREPARING -> when (e) {
            RecEvent.STARTED -> RecState.RECORDING; RecEvent.FAIL -> RecState.ERROR; RecEvent.STOP -> RecState.STOPPING; else -> null }
        RecState.RECORDING -> when (e) {
            RecEvent.PAUSE -> RecState.PAUSED; RecEvent.STOP -> RecState.STOPPING; RecEvent.FAIL -> RecState.ERROR; else -> null }
        RecState.PAUSED -> when (e) {
            RecEvent.RESUME -> RecState.RECORDING; RecEvent.STOP -> RecState.STOPPING; RecEvent.FAIL -> RecState.ERROR; else -> null }
        RecState.STOPPING -> when (e) { RecEvent.STOPPED -> RecState.IDLE; RecEvent.FAIL -> RecState.ERROR; else -> null }
        RecState.ERROR -> when (e) { RecEvent.RESET -> RecState.IDLE; RecEvent.START -> RecState.PREPARING; else -> null }
    }
}

data class RecConfig(
    val projectName: String,
    val sampleRate: Int = 48000,
    val channels: Int = 1,
    val gainDb: Float = 0f,
    val splitMinutes: Int = 0,
    val deviceId: Int = -1,
    val syncTone: Boolean = false
)

data class RecUiState(
    val state: RecState = RecState.IDLE,
    val elapsedMs: Long = 0,
    val peak: Float = 0f,
    val clipped: Boolean = false,
    val clipCount: Int = 0,
    val markers: List<Marker> = emptyList(),
    val routeName: String = "",
    val routeNote: String? = null,
    val warning: String? = null,
    val message: String? = null,
    val bytesWritten: Long = 0,
    val projectName: String = "",
    val savedCount: Int = 0
)

object Estimates {
    fun bytesPerSecond(sampleRate: Int, channels: Int) = sampleRate.toLong() * channels * 2
    fun bytesPerHour(sampleRate: Int, channels: Int) = bytesPerSecond(sampleRate, channels) * 3600
    /** Minutes of WAV recording that fit in `freeBytes`. */
    fun minutesAvailable(freeBytes: Long, sampleRate: Int, channels: Int): Long =
        freeBytes / bytesPerSecond(sampleRate, channels) / 60
}
