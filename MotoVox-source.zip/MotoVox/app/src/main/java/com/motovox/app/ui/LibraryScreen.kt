package com.motovox.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motovox.app.data.Naming
import com.motovox.app.data.RecStatus
import com.motovox.app.data.RecordingKind
import com.motovox.app.data.RecordingMeta
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SortBy(val label: String) { DATE("Date"), NAME("Name"), DURATION("Duration") }

@Composable
fun LibraryScreen(vm: MainViewModel) {
    val recs by vm.recordings.collectAsStateWithLifecycle()
    val playing by vm.playingKey.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf(SortBy.DATE) }
    var expanded by rememberSaveable { mutableStateOf<String?>(null) }
    var renameId by remember { mutableStateOf<String?>(null) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var exportId by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Pair<ExportKind, String>?>(null) }

    fun onUri(uri: android.net.Uri?) { val p = pending; pending = null; if (uri != null && p != null) vm.export(p.first, p.second, uri) }
    val wavL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { onUri(it) }
    val m4aL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { onUri(it) }
    val csvL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { onUri(it) }
    val jsonL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { onUri(it) }

    val shown = recs.filter { it.name.contains(query, ignoreCase = true) }.let { l ->
        when (sort) {
            SortBy.DATE -> l.sortedByDescending { it.createdAt }
            SortBy.NAME -> l.sortedBy { it.name.lowercase() }
            SortBy.DURATION -> l.sortedByDescending { it.durationMs }
        }
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Text("Library", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Search") },
                leadingIcon = { Icon(Icons.Filled.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.padding(horizontal = 16.dp)) { ChipRow(SortBy.values().map { it.label to it }, sort) { sort = it } }
            Text("${recs.size} item${if (recs.size == 1) "" else "s"} • ${formatBytes(vm.usedBytes())} used • ${formatBytes(vm.freeBytes())} free on this phone",
                Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (recs.isEmpty()) Text("Nothing here yet. Your recordings, processed voices and mixes will appear in this list.", Modifier.padding(16.dp))
        }
        items(shown, key = { it.id }) { m ->
            RecordingCard(m, vm, playing == m.id, expanded == m.id,
                onToggle = { expanded = if (expanded == m.id) null else m.id },
                onExport = { exportId = m.id }, onRename = { renameId = m.id }, onDelete = { deleteId = m.id })
        }
    }

    exportId?.let { id ->
        val m = recs.firstOrNull { it.id == id }
        if (m == null) exportId = null else AlertDialog(
            onDismissRequest = { exportId = null },
            title = { Text("Export “${m.name}”") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Choose a format, then pick where to save it.", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { pending = ExportKind.WAV to id; exportId = null; wavL.launch(Naming.fileName(m.name, m.createdAt, "", "wav")) }) { Text("WAV — full quality") }
                    TextButton(onClick = { pending = ExportKind.M4A to id; exportId = null; m4aL.launch(Naming.fileName(m.name, m.createdAt, "", "m4a")) }) { Text("M4A (AAC) — compact") }
                    TextButton(enabled = m.markers.isNotEmpty(), onClick = { pending = ExportKind.MARKERS_CSV to id; exportId = null; csvL.launch(Naming.fileName(m.name, m.createdAt, "markers", "csv")) }) { Text("Markers — CSV") }
                    TextButton(enabled = m.markers.isNotEmpty(), onClick = { pending = ExportKind.MARKERS_JSON to id; exportId = null; jsonL.launch(Naming.fileName(m.name, m.createdAt, "markers", "json")) }) { Text("Markers — JSON") }
                    TextButton(onClick = { pending = ExportKind.METADATA to id; exportId = null; jsonL.launch(Naming.fileName(m.name, m.createdAt, "metadata", "json")) }) { Text("Project metadata — JSON") }
                    Text("Phone and camera clocks and start delays differ. Use the sync tone or markers to line audio up in your editor; MotoVox doesn't promise frame-perfect sync.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onClick = { exportId = null }) { Text("Close") } }
        )
    }

    renameId?.let { id ->
        val m = recs.firstOrNull { it.id == id }
        var text by remember(id) { mutableStateOf(m?.name ?: "") }
        AlertDialog(onDismissRequest = { renameId = null }, title = { Text("Rename") },
            text = { OutlinedTextField(text, { text = it.take(80) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(id, text); renameId = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renameId = null }) { Text("Cancel") } })
    }

    deleteId?.let { id ->
        val m = recs.firstOrNull { it.id == id }
        AlertDialog(onDismissRequest = { deleteId = null }, title = { Text("Delete recording?") },
            text = { Text("“${m?.name ?: ""}” will be permanently deleted from this phone. Files you already exported are not affected.") },
            confirmButton = { TextButton(onClick = { vm.delete(id); deleteId = null }) { Text("Delete", color = MV.Red) } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Keep") } })
    }
}

@Composable
private fun RecordingCard(m: RecordingMeta, vm: MainViewModel, isPlaying: Boolean, expanded: Boolean,
                          onToggle: () -> Unit, onExport: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val exists = vm.fileOf(m).exists()
    var notes by remember(m.id, m.notes) { mutableStateOf(m.notes) }
    val date = remember(m.createdAt) { SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(m.createdAt)) }
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(m.name, fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Text("$date • ${Naming.formatTime(m.durationMs)} • WAV ${"%.1f".format(m.sampleRate / 1000.0)} kHz ${if (m.channels == 2) "stereo" else "mono"} • ${formatBytes(m.sizeBytes)}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(when (m.kind) { RecordingKind.VOICE -> "Voice recording"; RecordingKind.PROCESSED -> "Processed voice"; RecordingKind.MIX -> "Final mix" } +
                        when (m.status) { RecStatus.COMPLETE -> ""; RecStatus.RECOVERED -> " • recovered after an interruption"; RecStatus.RECORDING -> " • interrupted" },
                        style = MaterialTheme.typography.labelSmall, color = MV.Green)
                }
                IconButton(onClick = { vm.togglePlay(m.id, vm.fileOf(m)) }, enabled = exists) {
                    Icon(if (isPlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow, if (isPlaying) "Stop playback" else "Play ${m.name}") }
                IconButton(onClick = { vm.toggleFavorite(m.id) }) {
                    Icon(if (m.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, if (m.favorite) "Remove favorite" else "Mark favorite",
                        tint = if (m.favorite) MV.Red else MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            if (!exists) Text("The audio file is missing. It may have been moved or deleted outside MotoVox. You can delete this entry.", color = MV.Amber, style = MaterialTheme.typography.bodySmall)
            if (expanded) {
                if (m.markers.isNotEmpty()) {
                    Text("Markers", fontWeight = FontWeight.SemiBold)
                    m.markers.sortedBy { it.timeMs }.forEach { Text("${Naming.formatTime(it.timeMs, true)}  ${it.label}", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) }
                }
                if (m.inputDevice.isNotBlank()) Text("Input: ${m.inputDevice}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("Project notes") }, modifier = Modifier.fillMaxWidth())
                if (notes != m.notes) TextButton(onClick = { vm.setNotes(m.id, notes) }) { Text("Save notes") }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onExport, enabled = exists) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(4.dp)); Text("Export") }
                    TextButton(onClick = onRename) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(4.dp)); Text("Rename") }
                    TextButton(onClick = { vm.duplicate(m.id) }, enabled = exists) { Icon(Icons.Filled.ContentCopy, null); Spacer(Modifier.width(4.dp)); Text("Copy") }
                }
                TextButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null, tint = MV.Red); Spacer(Modifier.width(4.dp)); Text("Delete", color = MV.Red) }
            }
        }
    }
}
