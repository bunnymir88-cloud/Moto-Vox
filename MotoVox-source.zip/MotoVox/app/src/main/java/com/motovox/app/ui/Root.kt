package com.motovox.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("record", "Record", Icons.Filled.Mic),
    Tab("fx", "Voice FX", Icons.Filled.GraphicEq),
    Tab("mix", "Music & Mix", Icons.Filled.MusicNote),
    Tab("library", "Library", Icons.Filled.LibraryMusic),
    Tab("settings", "Settings", Icons.Filled.Settings)
)

@Composable
fun MotoVoxRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val notice by vm.notice.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true; restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(t.label, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            notice?.let { Banner(it, isError = true) { vm.notice.value = null } }
            if (job.running) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(job.title + "…")
                        LinearProgressIndicator(progress = { job.progress }, Modifier.fillMaxWidth())
                        TextButton(onClick = vm::cancelJob) { Text("Cancel") }
                    }
                }
            } else job.message?.let { Banner(it, job.isError) { vm.dismissJob() } }

            NavHost(nav, startDestination = "record", modifier = Modifier.weight(1f)) {
                composable("record") { RecordScreen(vm, onMicTest = { nav.navigate("mictest") }) }
                composable("fx") { VoiceFxScreen(vm) }
                composable("mix") { MixScreen(vm) }
                composable("library") { LibraryScreen(vm) }
                composable("settings") { SettingsScreen(vm, onMicTest = { nav.navigate("mictest") }) }
                composable("mictest") { MicTestScreen(vm, onBack = { nav.popBackStack() }) }
            }
        }
    }
}
