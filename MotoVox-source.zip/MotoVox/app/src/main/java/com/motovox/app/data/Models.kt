package com.motovox.app.data

import org.json.JSONArray
import org.json.JSONObject

enum class RecordingKind { VOICE, PROCESSED, MIX }
enum class RecStatus { RECORDING, COMPLETE, RECOVERED }

data class Marker(val timeMs: Long, val label: String)

data class RecordingMeta(
    val id: String,
    val name: String,
    val fileName: String,
    val kind: RecordingKind,
    val createdAt: Long,
    val durationMs: Long,
    val sampleRate: Int,
    val channels: Int,
    val sizeBytes: Long,
    val status: RecStatus,
    val favorite: Boolean = false,
    val notes: String = "",
    val markers: List<Marker> = emptyList(),
    val parentId: String? = null,
    val inputDevice: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("fileName", fileName)
        put("kind", kind.name); put("createdAt", createdAt); put("durationMs", durationMs)
        put("sampleRate", sampleRate); put("channels", channels); put("sizeBytes", sizeBytes)
        put("status", status.name); put("favorite", favorite); put("notes", notes)
        put("parentId", parentId ?: JSONObject.NULL); put("inputDevice", inputDevice)
        put("markers", JSONArray().also { arr ->
            markers.forEach { arr.put(JSONObject().put("timeMs", it.timeMs).put("label", it.label)) }
        })
    }

    companion object {
        fun fromJson(o: JSONObject): RecordingMeta {
            val ms = o.optJSONArray("markers") ?: JSONArray()
            return RecordingMeta(
                id = o.getString("id"),
                name = o.getString("name"),
                fileName = o.getString("fileName"),
                kind = runCatching { RecordingKind.valueOf(o.getString("kind")) }.getOrDefault(RecordingKind.VOICE),
                createdAt = o.optLong("createdAt"),
                durationMs = o.optLong("durationMs"),
                sampleRate = o.optInt("sampleRate", 48000),
                channels = o.optInt("channels", 1),
                sizeBytes = o.optLong("sizeBytes"),
                status = runCatching { RecStatus.valueOf(o.getString("status")) }.getOrDefault(RecStatus.COMPLETE),
                favorite = o.optBoolean("favorite"),
                notes = o.optString("notes", ""),
                markers = (0 until ms.length()).map { i ->
                    ms.getJSONObject(i).let { Marker(it.getLong("timeMs"), it.optString("label", "")) }
                },
                parentId = if (o.isNull("parentId")) null else o.optString("parentId"),
                inputDevice = o.optString("inputDevice", "")
            )
        }
    }
}
