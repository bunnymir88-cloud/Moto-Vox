package com.motovox.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motovox.app.audio.InputKind
import com.motovox.app.permissions.Perms

@Composable
fun MicTestScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val st by vm.micTest.state.collectAsStateWithLifecycle()
    val inputs by vm.inputs.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val playing by vm.playingKey.collectAsStateWithLifecycle()
    val needsBt = inputs.firstOrNull { it.id == s.deviceId }?.kind == InputKind.BLUETOOTH
    DisposableEffect(Unit) { onDispose { vm.micTest.stop() } }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.filter { Perms.blocking(it.key) }.all { it.value }) { vm.stopPlayback(); vm.micTest.start(s.deviceId, s.sampleRate) }
        else vm.notice.value = "Microphone (and Bluetooth, for a Bluetooth mic) permission is needed to test."
    }
    fun go() {
        val miss = Perms.missing(ctx, needsBt).filter { Perms.blocking(it) }
        if (miss.isEmpty()) { vm.stopPlayback(); vm.micTest.start(s.deviceId, s.sampleRate) } else launcher.launch(miss.toTypedArray())
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
            Text("Microphone test", style = MaterialTheme.typography.headlineSmall)
        }

        SectionCard("Available inputs") {
            Row(Modifier.fillMaxWidth().clickable(enabled = !st.running) { vm.setDevice(-1) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = s.deviceId < 0, onClick = null, enabled = !st.running)
                Spacer(Modifier.width(8.dp)); Text("Automatic (Android default)")
            }
            inputs.forEach { d ->
                Row(Modifier.fillMaxWidth().clickable(enabled = !st.running) { vm.setDevice(d.id) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.deviceId == d.id, onClick = null, enabled = !st.running)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(d.name)
                        Text(d.typeLabel + " • rates: " + (if (d.sampleRates.isEmpty()) "any" else d.sampleRates.joinToString("/")) +
                            " • channels: " + (if (d.channelCounts.isEmpty()) "any" else d.channelCounts.joinToString("/")),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (inputs.none { it.kind != InputKind.BUILTIN })
                Text("No external microphone detected. Plug in a wired/USB mic or connect Bluetooth; this list updates automatically.", style = MaterialTheme.typography.bodySmall)
        }

        SectionCard("Live level") {
            LevelMeter(st.peak)
            if (st.route.isNotEmpty()) Text("Recording from: ${st.route}")
            st.routeNote?.let { Text(it, color = MV.Amber, style = MaterialTheme.typography.bodySmall) }
            if (st.sampleRate > 0) Text("Delivered format: ${st.sampleRate} Hz, ${st.channels} channel${if (st.channels > 1) "s" else ""}", style = MaterialTheme.typography.bodySmall)
            if (st.clipped) Text("Clipping detected.", color = MV.Red)
            if (st.running) Text("Testing… ${st.elapsedMs / 1000}s. Speak normally.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!st.running) Button(onClick = { go() }) { Text("Start 8-second test") }
                else Button(onClick = { vm.micTest.stop() }) { Text("Stop") }
                OutlinedButton(onClick = { vm.togglePlay("mictest", vm.micTest.file) }, enabled = st.hasResult && !st.running) {
                    Text(if (playing == "mictest") "Stop playback" else "Play recording") }
            }
            if (!st.running && st.hasResult) Text(vm.micTest.verdict(st))
            st.message?.let { Text(it, color = MV.Amber) }
        }

        SectionCard("Troubleshooting") { TROUBLESHOOTING.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) } }
    }
}
