package com.motovox.app.effects

import kotlin.math.pow

enum class VoiceEffect(val label: String, val blurb: String) {
    ORIGINAL("Original", "No effect"),
    DEEP("Deep Voice", "Pitch down with extra low-end weight"),
    LOW("Low Pitch", "Pitch down"),
    HIGH("High Pitch", "Pitch up"),
    CHIPMUNK("Chipmunk", "Strong pitch up"),
    ROBOT("Robot", "Ring modulation + metallic comb"),
    RADIO("Radio", "Narrow band-pass with distortion"),
    ECHO("Echo", "Repeating delay"),
    REVERB("Reverb", "Room reverberation"),
    MONSTER("Monster", "Heavy pitch drop, growl and tail"),
    CUSTOM("Custom", "Your own pitch + echo amount")
}

enum class EqPreset(val label: String) { NONE("Flat"), CLARITY("Voice clarity"), WARM("Warm"), BRIGHT("Bright") }

data class FxParams(val effect: VoiceEffect = VoiceEffect.ORIGINAL, val intensity: Float = 0.5f, val customSemitones: Float = 0f)

data class EnhanceParams(
    val gainDb: Float = 0f,
    val highPass: Boolean = false,
    val hpfHz: Float = 90f,
    val windFilter: Boolean = false,
    val gate: Boolean = false,
    val eq: EqPreset = EqPreset.NONE,
    val compressor: Boolean = false,
    val limiter: Boolean = true
) {
    val isNeutral get() = gainDb == 0f && !highPass && !windFilter && !gate && eq == EqPreset.NONE && !compressor
}

object ChainBuilder {
    fun semitonesToRatio(st: Float) = 2f.pow(st / 12f)

    fun tailSeconds(fx: FxParams) = when (fx.effect) {
        VoiceEffect.ECHO, VoiceEffect.REVERB, VoiceEffect.MONSTER -> 3f
        VoiceEffect.CUSTOM -> if (fx.intensity > 0.02f) 3f else 0.3f
        else -> 0.3f
    }

    fun build(sr: Int, e: EnhanceParams, fx: FxParams): Array<Stage> {
        val s = ArrayList<Stage>()
        if (e.gainDb != 0f) s += Gain(e.gainDb)
        if (e.highPass) s += Biquad.highPass(sr, e.hpfHz)
        if (e.windFilter) { s += Biquad.highPass(sr, 160f); s += Biquad.highPass(sr, 160f) } // 4th-order rumble cut
        if (e.gate) s += NoiseGate(sr)
        when (e.eq) {
            EqPreset.NONE -> {}
            EqPreset.CLARITY -> { s += Biquad.peaking(sr, 250f, -2.5f, 1.0); s += Biquad.peaking(sr, 3000f, 3f, 0.9) }
            EqPreset.WARM -> { s += Biquad.peaking(sr, 180f, 2.5f, 0.9); s += Biquad.peaking(sr, 5500f, -2f, 0.9) }
            EqPreset.BRIGHT -> s += Biquad.peaking(sr, 4500f, 3.5f, 0.8)
        }
        if (e.compressor) s += Compressor(sr, -22f, 3f, 10f, 160f, 4f)
        s += effectStages(sr, fx)
        if (e.limiter) s += Limiter(sr)
        return s.toTypedArray()
    }

    private fun effectStages(sr: Int, fx: FxParams): List<Stage> {
        val i = fx.intensity.coerceIn(0f, 1f)
        fun pitch(st: Float) = if (kotlin.math.abs(st) < 0.05f) null else PitchShifter(sr, semitonesToRatio(st))
        return when (fx.effect) {
            VoiceEffect.ORIGINAL -> emptyList()
            VoiceEffect.DEEP -> listOfNotNull(pitch(-(4f + 6f * i)), Biquad.peaking(sr, 150f, 4f * i, 0.9))
            VoiceEffect.LOW -> listOfNotNull(pitch(-(1.5f + 4.5f * i)))
            VoiceEffect.HIGH -> listOfNotNull(pitch(1.5f + 4.5f * i))
            VoiceEffect.CHIPMUNK -> listOfNotNull(pitch(5f + 7f * i))
            VoiceEffect.ROBOT -> listOf(RingMod(sr, 55f + 40f * i, 0.6f + 0.4f * i), Echo(sr, 8f, 0.35f + 0.25f * i, 0.5f))
            VoiceEffect.RADIO -> listOf(Biquad.highPass(sr, 450f), Biquad.lowPass(sr, 3000f), SoftClip(1f + 4f * i), Gain(-2f))
            VoiceEffect.ECHO -> listOf(Echo(sr, 280f, 0.25f + 0.35f * i, 0.35f + 0.3f * i))
            VoiceEffect.REVERB -> listOf(Reverb(sr, 0.4f + 0.6f * i, 0.15f + 0.45f * i))
            VoiceEffect.MONSTER -> listOfNotNull(pitch(-(6f + 5f * i)), RingMod(sr, 30f, 0.25f * i), Reverb(sr, 0.5f, 0.15f))
            VoiceEffect.CUSTOM -> buildList {
                pitch(fx.customSemitones)?.let { add(it) }
                if (i > 0.02f) add(Echo(sr, 240f, 0.3f, i * 0.5f))
            }
        }
    }
}
