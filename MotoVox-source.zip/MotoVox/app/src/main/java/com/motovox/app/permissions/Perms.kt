package com.motovox.app.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

data class PermStatus(val permission: String, val label: String, val purpose: String, val granted: Boolean, val required: Boolean)

object Perms {
    fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun hasMic(ctx: Context) = granted(ctx, Manifest.permission.RECORD_AUDIO)

    /** Pure function (testable): permissions to request before starting a recording on a given API level. */
    fun requiredForRecording(sdk: Int, needsBluetooth: Boolean): List<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (sdk >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        if (sdk >= 31 && needsBluetooth) add(Manifest.permission.BLUETOOTH_CONNECT)
    }

    /** Permissions that must be granted (notifications are requested but recording still works without them). */
    fun blocking(p: String) = p != Manifest.permission.POST_NOTIFICATIONS

    fun missing(ctx: Context, needsBluetooth: Boolean): List<String> =
        requiredForRecording(Build.VERSION.SDK_INT, needsBluetooth).filter { !granted(ctx, it) }

    fun diagnostics(ctx: Context): List<PermStatus> = buildList {
        add(PermStatus(Manifest.permission.RECORD_AUDIO, "Microphone", "Records your voice. Required.", hasMic(ctx), true))
        if (Build.VERSION.SDK_INT >= 33) add(PermStatus(Manifest.permission.POST_NOTIFICATIONS, "Notifications",
            "Shows the recording status with a Stop button.", granted(ctx, Manifest.permission.POST_NOTIFICATIONS), false))
        if (Build.VERSION.SDK_INT >= 31) add(PermStatus(Manifest.permission.BLUETOOTH_CONNECT, "Nearby devices (Bluetooth)",
            "Needed only to use a Bluetooth headset microphone.", granted(ctx, Manifest.permission.BLUETOOTH_CONNECT), false))
    }
}
