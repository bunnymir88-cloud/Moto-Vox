package com.motovox.app

import com.motovox.app.audio.WavIO
import com.motovox.app.effects.*
import com.motovox.app.mixer.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

class DspAndMixTest {
    @get:Rule val tmp = TemporaryFolder()
    private val sr = 48000
    private fun sine(f: Float, n: Int, a: Float = 0.5f) = FloatArray(n) { (a * sin(2.0 * PI * f * it / sr)).toFloat() }
    private fun rms(x: FloatArray, from: Int = 0) = sqrt(x.drop(from).sumOf { (it * it).toDouble() } / (x.size - from)).toFloat()
    private fun crossingsHz(y: FloatArray, start: Int, n: Int): Float {
        var c = 0; for (i in start until start + n - 1) if (y[i] <= 0f && y[i + 1] > 0f) c++
        return c * sr.toFloat() / n
    }

    @Test fun pitchShifterMovesFrequency() {
        for (st in listOf(-6f, 3f, 7f)) {
            val ps = PitchShifter(sr, ChainBuilder.semitonesToRatio(st))
            val y = sine(440f, sr).map { ps.process(it) }.toFloatArray()
            val expected = 440f * ChainBuilder.semitonesToRatio(st)
            assertEquals("shift $st", expected, crossingsHz(y, 15000, 24000), expected * 0.03f)
        }
    }

    @Test fun pitchShifterAtUnityPreservesLevel() {
        val ps = PitchShifter(sr, 1f)
        val y = sine(440f, sr).map { ps.process(it) }.toFloatArray()
        assertEquals(rms(sine(440f, sr)), rms(y, 15000), 0.02f)
    }

    @Test fun limiterNeverExceedsCeiling() {
        val lim = Limiter(sr, -0.5f); val ceil = Math.pow(10.0, -0.5 / 20).toFloat()
        val peak = sine(220f, sr, 3f).maxOf { abs(lim.process(it)) }
        assertTrue("peak=$peak", peak <= ceil + 1e-4f)
    }

    @Test fun highPassAttenuatesRumbleAndPassesVoice() {
        val hp = Biquad.highPass(sr, 90f); val hp2 = Biquad.highPass(sr, 90f)
        val low = sine(30f, sr).map { hp.process(it) }.toFloatArray()
        val mid = sine(1000f, sr).map { hp2.process(it) }.toFloatArray()
        assertTrue(rms(low, 24000) < rms(sine(30f, sr), 24000) * 0.2f)
        assertEquals(rms(sine(1000f, sr), 24000), rms(mid, 24000), 0.01f)
    }

    @Test fun gainStageIsExactly6dBForDouble() = assertEquals(0.5f, Gain(6.0206f).process(0.25f), 0.001f)

    @Test fun chainOrderingKeepsLimiterLast() {
        val chain = ChainBuilder.build(sr, EnhanceParams(gainDb = 12f, limiter = true), FxParams(VoiceEffect.ECHO, 1f))
        assertTrue(chain.last() is Limiter)
        assertTrue(chain.isNotEmpty())
        assertTrue(ChainBuilder.build(sr, EnhanceParams(limiter = false), FxParams()).isEmpty())
    }

    @Test fun everyEffectProducesFiniteBoundedAudio() {
        for (fx in VoiceEffect.values()) {
            val chain = ChainBuilder.build(sr, EnhanceParams(), FxParams(fx, 1f, 5f))
            val bad = sine(300f, sr / 2).any { x -> var v = x; for (s in chain) v = s.process(v); v.isNaN() || abs(v) > 1.0f }
            assertFalse("effect $fx", bad)
        }
    }

    @Test fun fadeGainCurve() {
        assertEquals(0f, MixMath.fadeGain(0, 0, 1000, 100, 100), 0f)
        assertEquals(0.5f, MixMath.fadeGain(50, 0, 1000, 100, 100), 0.001f)
        assertEquals(1f, MixMath.fadeGain(500, 0, 1000, 100, 100), 0f)
        assertEquals(0.5f, MixMath.fadeGain(950, 0, 1000, 100, 100), 0.001f)
        assertEquals(1f, MixMath.fadeGain(0, 0, 1000, 0, 0), 0f)
    }

    private fun wav(name: String, data: ShortArray): java.io.File = tmp.newFile(name).also { f ->
        WavIO.Writer(f, sr, 1).use { it.write(data, data.size) }
    }

    @Test fun mixIsAsLongAsVoiceAndNeverClips() {
        val voice = wav("v.wav", ShortArray(sr * 2) { (sin(2 * PI * 300 * it / sr) * 30000).toInt().toShort() })
        val music = wav("m.wav", ShortArray(sr / 2) { (sin(2 * PI * 80 * it / sr) * 32000).toInt().toShort() })
        val out = tmp.newFile("o.wav")
        val r = Mixer.mix(voice, music, out, MixParams(musicGainDb = 0f, duckDb = 0f, loop = true))
        assertTrue(r.error, r.ok)
        val info = WavIO.readInfo(out)!!
        assertEquals(sr * 2L, info.frames)
        WavIO.Reader(out).use { rd -> val b = ShortArray(4096); var peak = 0
            while (true) { val n = rd.read(b); if (n == 0) break; for (i in 0 until n) peak = maxOf(peak, abs(b[i].toInt())) }
            assertTrue("peak=$peak", peak < 32767 * 0.95) }
    }

    @Test fun musicOffsetKeepsEarlyPartVoiceOnly() {
        val voice = wav("v2.wav", ShortArray(sr) { 0 })          // silent voice
        val music = wav("m2.wav", ShortArray(sr) { 8000 })        // constant music
        val out = tmp.newFile("o2.wav")
        assertTrue(Mixer.mix(voice, music, out, MixParams(musicGainDb = 0f, musicOffsetMs = 500, fadeInMs = 0, fadeOutMs = 0, duckDb = 0f)).ok)
        WavIO.Reader(out).use { rd -> val b = ShortArray(sr); rd.read(b)
            assertEquals(0, b[sr / 4].toInt()); assertTrue(b[sr * 3 / 4] > 6000) }
    }

    @Test fun duckingLowersMusicWhileVoiceSpeaks() {
        val voice = wav("v3.wav", ShortArray(sr * 2) { (sin(2 * PI * 300 * it / sr) * 12000).toInt().toShort() })
        val music = wav("m3.wav", ShortArray(sr * 2) { (sin(2 * PI * 90 * it / sr) * 8000).toInt().toShort() })
        val flat = tmp.newFile("flat.wav"); val duck = tmp.newFile("duck.wav")
        val base = MixParams(musicGainDb = 0f, fadeInMs = 0, fadeOutMs = 0, limiter = false)
        assertTrue(Mixer.mix(voice, music, flat, base.copy(duckDb = 0f)).ok)
        assertTrue(Mixer.mix(voice, music, duck, base.copy(duckDb = -12f)).ok)
        fun energy(f: java.io.File): Double = WavIO.Reader(f).use { r ->
            val b = ShortArray(sr * 2); val n = r.read(b)
            (0 until n).sumOf { b[it].toDouble() * b[it].toDouble() }
        }
        assertTrue(energy(duck) < energy(flat) * 0.9)
    }

    @Test fun emptyTrimRangeIsReportedNotCrashed() {
        val voice = wav("v4.wav", ShortArray(sr)); val music = wav("m4.wav", ShortArray(sr))
        val r = Mixer.mix(voice, music, tmp.newFile("o4.wav"), MixParams(trimStartMs = 900, trimEndMs = 900))
        assertFalse(r.ok); assertNotNull(r.error)
    }

    @Test fun offlineProcessorLeavesSourceUntouchedAndWritesTail() {
        val src = wav("s.wav", ShortArray(sr) { (sin(2 * PI * 300 * it / sr) * 9000).toInt().toShort() })
        val before = src.readBytes(); val dst = tmp.newFile("d.wav")
        val r = OfflineProcessor.run(src, dst, ChainBuilder.build(sr, EnhanceParams(), FxParams(VoiceEffect.REVERB, 0.8f)), 2f)
        assertTrue(r.ok); assertArrayEquals(before, src.readBytes())
        assertEquals(sr * 3L, WavIO.readInfo(dst)!!.frames)  // 1 s audio + 2 s tail
    }

    @Test fun linearResamplerChangesRate() {
        val rs = LinearResampler(44100, 48000); var n = 0
        repeat(44100) { rs.feed(0.1f) { n++ } }
        assertEquals(48000.0, n.toDouble(), 2.0)
    }
}
