package com.motovox.app

import com.motovox.app.audio.WavIO
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.RandomAccessFile

class WavIOTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun writeSine(name: String, frames: Int, sr: Int = 48000): java.io.File {
        val f = tmp.newFile(name)
        WavIO.Writer(f, sr, 1).use { w ->
            val s = ShortArray(frames) { (Math.sin(2 * Math.PI * 440 * it / sr) * 10000).toInt().toShort() }
            w.write(s, s.size)
        }
        return f
    }

    @Test fun finalizedFileHasCorrectHeaderAndRoundTrips() {
        val f = writeSine("a.wav", 4800)
        assertEquals(44L + 9600, f.length())
        val info = WavIO.readInfo(f)!!
        assertEquals(48000, info.sampleRate); assertEquals(1, info.channels); assertEquals(4800L, info.frames); assertEquals(100L, info.durationMs)
        WavIO.Reader(f).use { r ->
            val b = ShortArray(4800); assertEquals(4800, r.read(b))
            assertEquals((Math.sin(2 * Math.PI * 440 * 100 / 48000) * 10000).toInt().toShort(), b[100])
            assertEquals(0, r.read(b))
        }
        assertNull(WavIO.validate(f))
    }

    @Test fun interruptedFileWithZeroedHeaderIsRepaired() {
        val f = writeSine("crash.wav", 2400)
        RandomAccessFile(f, "rw").use { WavIO.writeHeader(it, 48000, 1, 0) } // simulate crash: sizes never patched
        RandomAccessFile(f, "rw").use { it.setLength(it.length() + 1) }        // plus a torn half-sample at the end
        assertTrue(WavIO.repairHeader(f))
        assertEquals(2400L, WavIO.readInfo(f)!!.frames)
        assertEquals(44L + 4800, f.length())
    }

    @Test fun periodicHeaderFlushKeepsFileValidMidRecording() {
        val f = tmp.newFile("live.wav")
        val w = WavIO.Writer(f, 48000, 1)
        w.write(ShortArray(1000), 1000); w.flushHeader()
        assertEquals(1000L, WavIO.readInfo(f)!!.frames) // readable before close()
        w.write(ShortArray(500), 500); w.close()
        assertEquals(1500L, WavIO.readInfo(f)!!.frames)
    }

    @Test fun invalidFilesAreRejectedWithMessage() {
        val junk = tmp.newFile("junk.wav").apply { writeBytes(ByteArray(200) { 7 }) }
        assertNull(WavIO.readInfo(junk)); assertNotNull(WavIO.validate(junk))
        assertNotNull(WavIO.validate(java.io.File(tmp.root, "missing.wav")))
        assertFalse(WavIO.repairHeader(junk))
    }

    @Test fun seekFrameAndStereoFrames() {
        val f = tmp.newFile("st.wav")
        WavIO.Writer(f, 44100, 2).use { w -> w.write(ShortArray(2000) { it.toShort() }, 2000) }
        WavIO.Reader(f).use { r ->
            assertEquals(1000L, r.info.frames)
            r.seekFrame(10); val b = ShortArray(4); r.read(b)
            assertArrayEquals(shortArrayOf(20, 21, 22, 23), b)
        }
    }
}
