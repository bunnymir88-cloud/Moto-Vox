package com.motovox.app

import com.motovox.app.data.*
import com.motovox.app.export.Exporter
import org.junit.Assert.*
import org.junit.Test
import java.util.TimeZone

class NamingAndMetadataTest {
    private val utc = TimeZone.getTimeZone("UTC")

    @Test fun sanitizeStripsUnsafeCharacters() {
        assertEquals("Ride_to_Alps", Naming.sanitize("  Ride to  Alps!? "))
        assertEquals("MotoVox", Naming.sanitize("///***"))
        assertEquals(40, Naming.sanitize("x".repeat(100)).length)
    }

    @Test fun fileNameIsDeterministicAndHasExtension() {
        // 2026-10-07T18:45:00Z
        val ts = 1_791_398_700_000L
        assertEquals("Morning_Ride_20261007_184500_voice.wav", Naming.fileName("Morning Ride", ts, "voice", "wav", utc))
        assertEquals("Morning_Ride_20261007_184500.m4a", Naming.fileName("Morning Ride", ts, "", "m4a", utc))
    }

    @Test fun defaultProjectUsesPrefixOrFallback() {
        val ts = 1_791_398_700_000L
        assertEquals("Ride 2026-10-07 18:45", Naming.defaultProject("", ts, utc))
        assertEquals("Alps 2026-10-07 18:45", Naming.defaultProject("Alps", ts, utc))
    }

    @Test fun formatTime() {
        assertEquals("00:05", Naming.formatTime(5_000))
        assertEquals("1:02:03", Naming.formatTime(3_723_000))
        assertEquals("00:01.250", Naming.formatTime(1_250, true))
        assertEquals("00:00", Naming.formatTime(-10))
    }

    @Test fun metadataJsonRoundTrip() {
        val m = RecordingMeta("id1", "Ride", "Ride.wav", RecordingKind.PROCESSED, 123L, 4567L, 48000, 1, 999L,
            RecStatus.RECOVERED, true, "notes", listOf(Marker(1500, "Scenic"), Marker(200, "Start")), "parent", "USB mic")
        assertEquals(m, RecordingMeta.fromJson(m.toJson()))
    }

    @Test fun markersCsvIsSortedAndEscaped() {
        val m = RecordingMeta("i", "Ride", "r.wav", RecordingKind.VOICE, 0, 10_000, 48000, 1, 0, RecStatus.COMPLETE,
            markers = listOf(Marker(5000, "He said \"wow\""), Marker(1000, "Start")))
        val lines = Exporter.markersCsv(m).trim().lines()
        assertEquals("index,time_ms,time,label", lines[0])
        assertEquals("1,1000,00:01.000,\"Start\"", lines[1])
        assertEquals("2,5000,00:05.000,\"He said \"\"wow\"\"\"", lines[2])
    }

    @Test fun markerExportStatesSyncLimitations() {
        val m = RecordingMeta("i", "Ride", "r.wav", RecordingKind.VOICE, 0, 1000, 48000, 1, 0, RecStatus.COMPLETE)
        assertTrue(Exporter.markersJson(m).contains("Phone and camera clocks"))
    }
}
