package com.motovox.app

import android.Manifest
import com.motovox.app.audio.AudioDevices
import com.motovox.app.audio.InputKind
import com.motovox.app.audio.Levels
import com.motovox.app.permissions.Perms
import com.motovox.app.recording.*
import org.junit.Assert.*
import org.junit.Test

class RecorderLogicTest {
    private fun run(start: RecState, vararg ev: RecEvent): RecState? {
        var s: RecState? = start
        for (e in ev) { s = RecStateMachine.next(s ?: return null, e) }
        return s
    }

    @Test fun normalLifecycle() =
        assertEquals(RecState.IDLE, run(RecState.IDLE, RecEvent.START, RecEvent.STARTED, RecEvent.STOP, RecEvent.STOPPED))

    @Test fun pauseAndResumeReturnToRecording() {
        assertEquals(RecState.PAUSED, run(RecState.IDLE, RecEvent.START, RecEvent.STARTED, RecEvent.PAUSE))
        assertEquals(RecState.RECORDING, run(RecState.IDLE, RecEvent.START, RecEvent.STARTED, RecEvent.PAUSE, RecEvent.RESUME))
        assertEquals(RecState.STOPPING, run(RecState.PAUSED, RecEvent.STOP)) // can stop while paused
    }

    @Test fun invalidTransitionsAreRejected() {
        assertNull(RecStateMachine.next(RecState.IDLE, RecEvent.PAUSE))
        assertNull(RecStateMachine.next(RecState.RECORDING, RecEvent.RESUME))
        assertNull(RecStateMachine.next(RecState.RECORDING, RecEvent.START))
        assertNull(RecStateMachine.next(RecState.STOPPING, RecEvent.PAUSE))
    }

    @Test fun errorRecovers() {
        assertEquals(RecState.ERROR, run(RecState.IDLE, RecEvent.START, RecEvent.FAIL))
        assertEquals(RecState.IDLE, run(RecState.ERROR, RecEvent.RESET))
        assertEquals(RecState.PREPARING, run(RecState.ERROR, RecEvent.START)) // can retry directly
        assertEquals(RecState.ERROR, run(RecState.RECORDING, RecEvent.FAIL))
    }

    @Test fun storageEstimates() {
        assertEquals(96_000L, Estimates.bytesPerSecond(48000, 1))
        assertEquals(345_600_000L, Estimates.bytesPerHour(48000, 1))
        assertEquals(60L, Estimates.minutesAvailable(96_000L * 3600, 48000, 1))
    }

    @Test fun levelMath() {
        assertEquals(0f, Levels.peakToDb(1f), 0.001f)
        assertEquals(-6.02f, Levels.peakToDb(0.5f), 0.01f)
        assertEquals(-120f, Levels.peakToDb(0f), 0f)
        assertEquals(0f, Levels.dbToFraction(-80f), 0f); assertEquals(1f, Levels.dbToFraction(0f), 0f)
        assertEquals(0.5f, Levels.dbToFraction(-30f), 0.001f)
        assertEquals(2f, Levels.dbToLinear(6.0206f), 0.001f)
    }

    @Test fun permissionsByApiLevel() {
        assertEquals(listOf(Manifest.permission.RECORD_AUDIO), Perms.requiredForRecording(30, true))
        assertEquals(listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.BLUETOOTH_CONNECT), Perms.requiredForRecording(31, true))
        assertEquals(listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), Perms.requiredForRecording(34, false))
        assertFalse(Perms.blocking(Manifest.permission.POST_NOTIFICATIONS)); assertTrue(Perms.blocking(Manifest.permission.RECORD_AUDIO))
    }

    @Test fun deviceClassification() {
        assertEquals(InputKind.BUILTIN, AudioDevices.classify(android.media.AudioDeviceInfo.TYPE_BUILTIN_MIC))
        assertEquals(InputKind.USB, AudioDevices.classify(android.media.AudioDeviceInfo.TYPE_USB_HEADSET))
        assertEquals(InputKind.WIRED, AudioDevices.classify(android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET))
        assertEquals(InputKind.BLUETOOTH, AudioDevices.classify(android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO))
        assertEquals(InputKind.OTHER, AudioDevices.classify(android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)) // output-only profile
    }
}
